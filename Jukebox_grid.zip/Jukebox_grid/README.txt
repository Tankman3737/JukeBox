JukeBox_grid layout for Attractmode 3.2

1: Put the AudioMode_xtra.nut in the plugins folder.

2: Start the layout and add up to 10 albums, I have mine in the main AM plus folder inside "music", be aware of the track name length as it doesn't scroll.

3: I use an Xbox 360 controller so set custom 1&2 for vol up/down ( Triggers)  and custom 4 for album select (LB).
look for the words.png ( or similar ) if you want to swap out what shows on screen for your own .png

4: Multiple options, some are layout specific. 

5: Know bugs. Sometimes when turning on/off the visualizers the track will change or volume goes up (WTF!!or not, depending on the wind direction)

I made almost all the artwork from scratch in Affinity photo, apart from a few background elements. I did have help from Claude.AI on the coding (what did you expect--i'm not Oomek or Chadnaut)

Have a play, have fun, let me know if you find any issues or just want to chat.