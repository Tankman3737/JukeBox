///////////////////////////////////////////////////
//
// Attract-Mode Frontend - AudioMode_xtra plugin
//
///////////////////////////////////////////////////
//
// Define the user-configurable options:
//


// Simple Volume Control Layout

class UserConfig </ help="A plugin to play background audio" /> {

	

	</ label="Source Directory 1",
		help="The full path to the first directory containing audio files",
		order=3 />
	dir1="";

	</ label="Source Directory 2",
		help="The full path to the second directory containing audio files",
		order=4 />
	dir2="";

	</ label="Source Directory 3",
		help="The full path to the third directory containing audio files",
		order=5 />
	dir3="";

	</ label="Source Directory 4",
		help="The full path to the fourth directory containing audio files",
		order=6 />
	dir4="";

	</ label="Source Directory 5",
		help="The full path to the fifth directory containing audio files",
		order=7 />
	dir5="";

	</ label="Source Directory 6",
		help="The full path to the sixth directory containing audio files",
		order=8 />
	dir6="";

	</ label="Source Directory 7",
		help="The full path to the seventh directory containing audio files",
		order=9 />
	dir7="";

	</ label="Source Directory 8",
		help="The full path to the eighth directory containing audio files",
		order=10 />
	dir8="";

	</ label="Source Directory 9",
		help="The full path to the ninth directory containing audio files",
		order=11 />
	dir9="";

	</ label="Source Directory 10",
		help="The full path to the tenth directory containing audio files",
		order=12 />
	dir10="";
}

fe.load_module( "file" );

class AudioMode_xtra
{
	m_list = [];
	m_index = 0;
	m_input_block = false;
	m_work = "";
	m_config = {};
	m_display_text = null;
	m_display_time = 0;
	m_folders = [];
	m_folder_names = [];
	m_current_folder = 0;
	m_current_volume = 50; // Track current volume

constructor()
{
    print(" ===== AUDIOMODE_XTRA v2.0 DEBUG VERSION LOADED ===== \n");
    
    m_display_text = fe.add_text( "",
        fe.layout.width/8,
        fe.layout.height/2,
        3*fe.layout.width/4,
        fe.layout.height/4 );

    m_display_text.word_wrap = true;
    m_display_text.charsize = fe.layout.height/24;
    m_display_text.set_rgb( 255, 255, 255 );
    m_display_text.set_bg_rgb( 20, 20, 20 );
    m_display_text.bg_alpha = 100;
    m_display_text.visible = false;

    fe.add_ticks_callback( this, "on_tick" );
    fe.add_transition_callback( this, "on_transition" );

    fe.ambient_sound.loop = false;

    m_config=fe.get_config();

    // Load saved volume from fe.nv (non-volatile storage)
    if (!("ambient_volume" in fe.nv)) {
        fe.nv.ambient_volume <- 50; // Default
    }
    m_current_volume = fe.nv.ambient_volume;
    fe.ambient_sound.volume = m_current_volume;
    print(" - AudioMode: Loaded volume from fe.nv: " + m_current_volume + "\n");

    // ... rest of constructor (folder setup, etc.)

	// Build list of configured directories
for (local i = 1; i <= 10; i++)  // Changed from 6 to 10
{
    local key = "dir" + i;
    if (key in m_config && m_config[key].len() > 0)
    {
        local full_path = fe.path_expand(m_config[key]);
        m_folders.append(full_path);
        
        // Extract folder name for display
        local parts = split(full_path, "\\/");
        if (parts.len() > 0)
            m_folder_names.append(parts[parts.len()-1]);
        else
            m_folder_names.append("Folder " + i);
    }
}

		if ( m_folders.len() > 0 )
		{
			load_playlist( m_folders[0] );
			index_to_current();
		}
		else
		{
			print( "AudioMode plugin error: no source directories configured\n" );
		}
	}

	function _callback( msg )
	{
		m_work += msg;
	}

	function load_playlist( path )
	{
		local dir = DirectoryListing( path );

		// Load playlist in order (no shuffle)
		m_list = dir.results;

		print( " - AudioMode plugin: found "
			+ m_list.len() + " file(s) in: " + path + "\n" );
	}


	// Set volume function
	function set_volume( vol )
	{
		if ( vol < 0 ) vol = 0;
		if ( vol > 100 ) vol = 100;
		
		m_current_volume = vol;
		fe.ambient_sound.volume = vol;
		save_volume(vol);
		
		print( " - AudioMode: Volume set to " + vol + "\n" );
		return true;
	}

	// Get current volume
	function get_volume()
	{
		return m_current_volume;
	}

	// Function to be called by layout to switch folders
	function switch_to_folder( folder_index )
	{
		if ( folder_index < 0 || folder_index >= m_folders.len() )
			return false;

		if ( folder_index == m_current_folder )
			return false; // Already on this folder

		m_current_folder = folder_index;

		// Load new folder's playlist
		load_playlist( m_folders[m_current_folder] );
		m_index = 0;
		
		// Start playing first track from new folder
		change_track( 0 );
		
		return true;
	}

	// Get current folder index
	function get_current_folder()
	{
		return m_current_folder;
	}

	// Get folder name by index
	function get_folder_name( index )
	{
		if ( index >= 0 && index < m_folder_names.len() )
			return m_folder_names[index];
		return "";
	}

	// Get total number of folders
	function get_folder_count()
	{
		return m_folders.len();
	}

	// Get current track index
	function get_current_track_index()
	{
		return m_index;
	}

	// Get total tracks in current folder
	function get_track_count()
	{
		return m_list.len();
	}

	// Get track filename by index
	function get_track_name( index )
	{
		if ( index >= 0 && index < m_list.len() )
		{
			local parts = split(m_list[index], "\\/");
			if (parts.len() > 0)
				return parts[parts.len()-1];
		}
		return "";
	}

	// Jump to specific track
	function play_track( track_index )
	{
		if ( track_index < 0 || track_index >= m_list.len() )
			return false;

		m_index = track_index;
		change_track( 0 );
		return true;
	}

	function index_to_current()
	{
		if ( fe.ambient_sound.playing && fe.ambient_sound.file_name.len() > 0 )
		{
			local playing_file = fe.ambient_sound.file_name;
			
			// Search current folder first
			for ( local idx=0; idx < m_list.len(); idx++ )
			{
				local full_path = fe.path_expand(m_list[idx]);
				if (playing_file == full_path)
				{
					m_index = idx;
					print(" - AudioMode: Synced to playing track " + idx + " in folder " + m_current_folder + "\n");
					return;
				}
			}
			
			// Not in current folder - search all others
			print(" - AudioMode: Track not in folder " + m_current_folder + ", searching other folders...\n");
			for (local f = 0; f < m_folders.len(); f++)
			{
				if (f == m_current_folder) continue; // Already checked
				
				local temp_list = DirectoryListing(m_folders[f]).results;
				
				for (local idx = 0; idx < temp_list.len(); idx++)
				{
					local full_path = fe.path_expand(temp_list[idx]);
					if (playing_file == full_path)
					{
						// Found it! Switch to this folder
						m_current_folder = f;
						load_playlist(m_folders[f]);
						m_index = idx;
						print(" - AudioMode: Found playing track in folder " + f + ", track " + idx + "\n");
						return;
					}
				}
			}
			
			// Not found anywhere - reload original folder and leave music alone
			print(" - AudioMode: Playing track not found, reloading folder " + m_current_folder + "\n");
			load_playlist(m_folders[m_current_folder]);
			m_index = 0;
			return;
		}

		// Nothing playing - start from beginning
		m_index = 0;
		change_track( 0 );
		print(" - AudioMode: Started playback from track 0\n");
	}

	function change_track( offset )
	{
		if ( m_list.len() <= 0 )
			return;

		m_index += ( offset % m_list.len() );

		if ( m_index < 0 )
			m_index += m_list.len();
		if ( m_index >= m_list.len() )
			m_index -= m_list.len();

		// play the next track
		fe.ambient_sound.file_name
			= fe.path_expand( m_list[ m_index ] );

		if ( fe.ambient_sound.file_name.len() < 1 )
		{
			m_list.remove( m_index );
			return change_track( offset );
		}

		fe.ambient_sound.playing = true;
		
		// Restore volume after track change
		fe.ambient_sound.volume = m_current_volume;
		
		m_display_text.msg = get_track_msg();
	}

	function get_track_msg()
	{
		if ( fe.ambient_sound.file_name.len() == 0 )
			return "";

		local title = fe.ambient_sound.get_metadata( "title" );
		if ( title.len() < 1 )
		{
			local n = split( fe.ambient_sound.file_name, "\\/" );
			if ( n.len() > 0 )
				return "Now Playing: " + n[ n.len()-1 ];
			else
				return "";
		}

		return "Now Playing: " + title + " - "
			+ fe.ambient_sound.get_metadata( "artist" ) + "\n\n"
			+ fe.ambient_sound.get_metadata( "album" );
	}

	function show_track_msg( flag, ttime )
	{
		if ( flag )
		{
			m_display_text.msg = get_track_msg();

 			if ( m_display_text.msg.len() > 0 )
			{
				m_display_time = ttime;
				m_display_text.visible = true;
				return;
			}
		}

		m_display_text.visible = false;
		m_display_time = 0;
	}

function on_tick( ttime )
{
    if ( fe.ambient_sound.playing == false )
        change_track( 1 );

    // Check if volume was changed externally (by layout)
    if (fe.ambient_sound.volume != m_current_volume)
    {
        m_current_volume = fe.ambient_sound.volume;
        fe.nv.ambient_volume = m_current_volume; // Save to fe.nv
        print(" - AudioMode: Saved volume to fe.nv: " + m_current_volume + "\n");
    }

    else
    {
        // Ensure volume stays consistent
        fe.ambient_sound.volume = m_current_volume;
    }
}
	function on_transition( ttype, var, ttime )
	{
		if ( ttype == Transition.FromGame )
			change_track( 1 );

		return false;
	}
}

// create an entry in the fe.plugin table in case anyone else wants to
// find this plugin
//
fe.plugin[ "AudioMode_xtra" ] <- AudioMode_xtra();

