/**
 * Jukebox_grid Layout
 *
 * @summary A short description.
 * @version 0.0.1 2026-1-9
 * @author Tankman3737
 * @url https://github.com/Tankman3737
 *
 * @requires
 * @module blur 0.1.0 https://github.com/Chadnaut/Attract-Mode-Modules
 * @module fade (Included with AM)
 * @module file (Included with AM)
 * @module inertia 3.00 https://github.com/oomek/attract-extra
 * @module mask 0.3.1 https://github.com/Chadnaut/Attract-Mode-Modules
 * @module scrollingtext 1.0
 * @module wheel 140.0 https://github.com/oomek/attract-extra
 */

class UserConfig {
    </ label="Visualizer", help="Visualizer On/Off", options="Yes,No", order=3 />
    Visualizers = "No";
}

cfg <- fe.get_config();

fe.layout.preserve_aspect_ratio = true;
fe.layout.width = 1920;
fe.layout.height = 1080;

fe.layout.width = 1920;
fe.layout.height = 1080;
local my_config = fe.get_config();

local flx = fe.layout.width;
local fly = fe.layout.height;
local flw = fe.layout.width;
local flh = fe.layout.height;

fe.load_module("fade");
fe.load_module("inertia");
fe.load_module("file");
fe.load_module("mask");
fe.load_module("wheel");

//==============================================
// MODE CONTROL & PLUGIN - SAFE INITIALIZATION
//==============================================
local active_mode = 1; // Start with songs active

// SAFE PLUGIN CHECK
local audiomode = null;
local plugin_available = false;

try {
    if ("AudioMode_xtra" in fe.plugin) {
        audiomode = fe.plugin["AudioMode_xtra"];
        plugin_available = true;
        fe.log("INFO: AudioMode_xtra plugin loaded successfully");
    } else {
        fe.log("WARNING: AudioMode_xtra plugin not found, running in limited mode");
    }
} catch (e) {
    fe.log("ERROR: Failed to check for AudioMode_xtra plugin: " + e);
    plugin_available = false;
}

//==============================================
// ALBUM TO FOLDER MAPPING - AUTO-DETECT
//==============================================
local total_albums = 0;
if (plugin_available && audiomode && audiomode.m_folders) {
    total_albums = audiomode.m_folders.len();
} else {
    fe.log("INFO: Running without AudioMode_xtra plugin, albums disabled");
}

local album_to_folder_map = {};
for (local i = 0; i < total_albums; i++) {
    album_to_folder_map[i] <- i;
}

local current_album_selection = 0;
local current_song_selection = 0;

//==============================================
// FOLDER STATE PERSISTENCE
//==============================================
if (!("jukebox_last_folder" in fe.nv)) {
    fe.nv.jukebox_last_folder <- 0;
}

if (!("jukebox_last_album" in fe.nv)) {
    fe.nv.jukebox_last_album <- 0;
}

if (!("jukebox_last_song" in fe.nv)) {
    fe.nv.jukebox_last_song <- 0;
}

//==============================================
// SONG LISTS - LOAD DATA
//==============================================
local album_song_lists = [];
local album_display_names = [];

function load_all_song_lists() {
    album_song_lists = [];
    album_display_names = [];

    if (!plugin_available || !audiomode) {
        fe.log("INFO: AudioMode_xtra not available, no songs loaded");
        // Add dummy data to prevent crashes
        album_song_lists.push([]);
        album_display_names.push(["No Audio Plugin Available"]);
        total_albums = 1;
        return;
    }

    for (local album_idx = 0; album_idx < total_albums; album_idx++) {
        local folder_idx = album_to_folder_map[album_idx];

        if (folder_idx < audiomode.m_folders.len()) {
            local folder_path = audiomode.m_folders[folder_idx];
            local dir = DirectoryListing(folder_path);

            local song_files = [];
            local display_names = [];

            foreach (filename in dir.results) {
                local lower_filename = filename.tolower();
                if (lower_filename.find(".jpg") != null || lower_filename.find(".jpeg") != null || lower_filename.find(".png") != null || lower_filename.find(".gif") != null || lower_filename.find(".bmp") != null) {
                    continue;
                }

                song_files.push(filename);

                local display_name = filename;
                local parts = split(filename, "/\\");
                if (parts.len() > 0) {
                    display_name = parts[parts.len() - 1];
                    local dot_pos = display_name.find(".", display_name.len() - 5);
                    if (dot_pos != null) {
                        display_name = display_name.slice(0, dot_pos);
                    }
                }
                display_names.push(display_name);
            }

            album_song_lists.push(song_files);
            album_display_names.push(display_names);
            fe.log("Album " + album_idx + ": Loaded " + song_files.len() + " songs");
        } else {
            album_song_lists.push([]);
            album_display_names.push([]);
        }
    }
}

//==============================================
// BACKGROUND IMAGES
//==============================================
local Etrack_top = fe.add_image("Classic_car_Artwork/8track_top3.png");
local Rtrack_bottom = fe.add_image("Classic_car_Artwork/8track_bottom3.png");

//==============================================
// SMALL ALBUM ART (corner display)
//==============================================
local album_art = fe.add_image("", 399, 774, 318, 318);
album_art.anchor = Anchor.Centre;

//==============================================
// VISUALIZER SURFACE
//==============================================
local vissurf = fe.add_surface(1030, 14, 700, 500);
local VW = 560;
local VH = 300;
vissurf.anchor = Anchor.Centre;
vissurf.zorder = 500;
fe.ambient_sound.fft_bands = 30;

//==============================================
// VOLUME CONTROL
//==============================================
local show_volume_display = true;
local volume_display_time = 0;
local volume_display_duration = 3000;

local numBars = 25;
local barWidth = 13;
local barHeight = 10;
local circleRadius = 82;

local volumeBars = [];

for (local i = 0; i < numBars; i++) {
    local angleRange = 256.0;
    local angle = (i / (numBars - 1).tofloat()) * angleRange;
    angle = angle - -142;

    local angleRad = (angle * PI) / 180.0;

    local xPos = 1425 + cos(angleRad) * circleRadius;
    local yPos = 199 + sin(angleRad) * circleRadius;

    local rect = fe.add_rectangle(xPos, yPos, barWidth, barHeight);
    rect.set_rgb(255, 0, 0);
    rect.anchor = Anchor.Centre;
    rect.rotation = angle + 90;
    rect.alpha = 250;
    rect.zorder = 500;
    volumeBars.append(rect);
}

//==============================================
// ALBUM & TRACK DISPLAY
//==============================================
local album_text = fe.add_text("", 690, 120, 550, 60);
album_text.font = "displdts.ttf";
album_text.charsize = 30;
album_text.set_rgb(255, 255, 255);
album_text.align = Align.MiddleLeft;
album_text.alpha = 50;

local track_text = fe.add_text("", 690, 180, 550, 60);
track_text.font = "displdts.ttf";
track_text.charsize = 30;
track_text.set_rgb(255, 255, 255);
track_text.align = Align.MiddleLeft;

//==============================================
// UPDATE DISPLAY FUNCTION
//==============================================
function update_car_display() {
    local album_num = current_album_selection + 1;
    local album_name = "";
    
    if (plugin_available && audiomode && current_album_selection < audiomode.m_folders.len()) {
        album_name = audiomode.get_folder_name(current_album_selection);

        // Load album art - try jpg first, then png
        local cover_jpg = audiomode.m_folders[current_album_selection] + "/cover.jpg";
        local cover_png = audiomode.m_folders[current_album_selection] + "/cover.png";

        album_art.file_name = cover_jpg;
        if (album_art.texture_width == 0) {
            album_art.file_name = cover_png;
        }
    } else {
        album_name = "please enable Audiomode_xtra plugin";
    
        album_art.file_name = "";
    }
    
    album_text.msg = (album_num + ": " + album_name).toupper();
    album_art.alpha = 0;

    local track_name = "";
    if (current_album_selection < album_display_names.len() && current_song_selection < album_display_names[current_album_selection].len()) {
        track_name = album_display_names[current_album_selection][current_song_selection];
    } else {
        track_name = "No Track Available";
    }
    track_text.msg = track_name.toupper();
}

local vol_button = fe.add_image("Classic_car_Artwork/vol_button.png", 1419, 195, 138, 138);
vol_button.anchor = Anchor.Centre;
vol_button.rotation_origin_x = 0.5;
vol_button.rotation_origin_y = 0.5;
vol_button.rotation = -40;

local w = VW.tofloat() / fe.ambient_sound.fft_bands;

local dotSize = 8;
local dotSpacing = 2;
local dotsPerBar = 14;

local bars_m = [];

for (local i = 0; i < fe.ambient_sound.fft_bands; i++) {
    local barDots = [];

    for (local d = 0; d < dotsPerBar; d++) {
        local xPos = i * w;
        local yPos = 500 - d * (dotSize + dotSpacing);

        local dot = vissurf.add_rectangle(xPos, yPos, dotSize, dotSize);
        dot.set_rgb(139, 140, 142);
        dot.alpha = 0;

        barDots.append(dot);
    }

    bars_m.push(barDots);
}

//==============================================
// VOLUME FUNCTIONS
//==============================================
function load_initial_volume() {
    local vol = "ambient_volume" in fe.nv ? fe.nv.ambient_volume : 50;

    fe.ambient_sound.volume = vol;
    vol_button.rotation = (vol / 100.0) * 270.0;

    local activeBars = floor(vol / (100.0 / numBars));
    fe.log("Setting " + activeBars + " bars active out of " + numBars);

    for (local i = 0; i < numBars; i++) {
        volumeBars[i].alpha = i < activeBars ? 255 : 0;
    }

    fe.log("Initial volume loaded: " + vol);
}

function show_volume(vol) {
    show_volume_display = true;
    volume_display_time = fe.layout.time;

    vol_button.rotation = (vol / 100.0) * 270.0;

    local activeBars = floor(vol / (100.0 / numBars));
    for (local i = 0; i < numBars; i++) {
        volumeBars[i].alpha = i < activeBars ? 255 : 0;
    }
}

function hide_volume() {
    show_volume_display = false;
}

function adjust_volume(amount) {
    local v = fe.ambient_sound.volume + amount;
    if (v < 0) v = 0;
    if (v > 100) v = 100;

    fe.ambient_sound.volume = v;
    fe.nv.ambient_volume = v;

    show_volume(v);
}

local volumeStep = 4;
local volumeChangeInterval = 200;
local lastVolumeChangeTime = 0;

//==============================================
// ARTTEST - SINGLE LOADING/EJECTING CASSETTE
//==============================================
local arttest = fe.add_image("", 965, 600, 600, 250);
arttest.transform_origin = Origin.Centre;
arttest.anchor = Anchor.Centre;
arttest = Inertia(arttest, 500, "alpha", "pinch_x", "y", "height", "width");

local Etrack_middle = fe.add_image("Classic_car_Artwork/8track_middle3.png");

//==============================================
// COVERFLOW - MULTIPLE CASSETTES THAT SLIDE
//==============================================
local cover_count = 9;
local album_covers = [];

// Positions from your original wheel
local cover_x_positions = [ -1140, -1140, -440, 260, 965, 1670, 2370, 3070, 3060 ];
local cover_y = 850;
local cover_width = 700;
local cover_height = 350;

for (local i = 0; i < cover_count; i++) {
    local cover = fe.add_image("", cover_x_positions[i], cover_y, cover_width, cover_height);
    cover.anchor = Anchor.Centre;
    cover.alpha = 0;
    cover = Inertia(cover, 350, "x", "alpha");
    album_covers.append(cover);
}

//==============================================
// COVERFLOW UPDATE FUNCTIONS - DEFINE BEFORE USE
//==============================================
local animating = false;
local animate_timer = 0;
local last_direction = "";

function update_coverflow_full() {
    local center_slot = 4;

    for (local slot = 0; slot < cover_count; slot++) {
        local offset = slot - center_slot;
        local album_idx = current_album_selection + offset;

        while (album_idx < 0) album_idx += total_albums;
        while (album_idx >= total_albums) album_idx -= total_albums;

        if (plugin_available && audiomode && album_idx < audiomode.m_folders.len()) {
            local track_jpg = audiomode.m_folders[album_idx] + "/track.jpg";
            local track_png = audiomode.m_folders[album_idx] + "/track.png";

            album_covers[slot].file_name = track_jpg;
            if (album_covers[slot].texture_width == 0) {
                album_covers[slot].file_name = track_png;
            }
        }

        album_covers[slot].x = cover_x_positions[slot];
        album_covers[slot].to_x = cover_x_positions[slot];
    }
}

function update_coverflow_left() {
    if (animating) return;
    animating = true;
    animate_timer = fe.layout.time;

    // Move all cassettes RIGHT
    for (local i = 0; i < cover_count; i++) {
        if (i < cover_count - 1) {
            album_covers[i].to_x = cover_x_positions[i + 1];
        }
    }
}

function update_coverflow_right() {
    if (animating) return;
    animating = true;
    animate_timer = fe.layout.time;

    // Move all cassettes LEFT
    for (local i = 0; i < cover_count; i++) {
        if (i > 0) {
            album_covers[i].to_x = cover_x_positions[i - 1];
        }
    }
}

function complete_coverflow_left() {
    // Swap images
    for (local i = cover_count - 1; i > 0; i--) {
        album_covers[i].file_name = album_covers[i - 1].file_name;
    }

    // Load new leftmost
    local leftmost_album = current_album_selection - 4;
    while (leftmost_album < 0) leftmost_album += total_albums;

    if (plugin_available && audiomode && leftmost_album < audiomode.m_folders.len()) {
        local track_jpg = audiomode.m_folders[leftmost_album] + "/track.jpg";
        local track_png = audiomode.m_folders[leftmost_album] + "/track.png";

        album_covers[0].file_name = track_jpg;
        if (album_covers[0].texture_width == 0) {
            album_covers[0].file_name = track_png;
        }
    }

    // Reset positions
    for (local i = 0; i < cover_count; i++) {
        album_covers[i].x = cover_x_positions[i];
        album_covers[i].to_x = cover_x_positions[i];
    }

    animating = false;
}

function complete_coverflow_right() {
    // Swap images
    for (local i = 0; i < cover_count - 1; i++) {
        album_covers[i].file_name = album_covers[i + 1].file_name;
    }

    // Load new rightmost
    local rightmost_album = current_album_selection + 4;
    while (rightmost_album >= total_albums) rightmost_album -= total_albums;

    if (plugin_available && audiomode && rightmost_album < audiomode.m_folders.len()) {
        local track_jpg = audiomode.m_folders[rightmost_album] + "/track.jpg";
        local track_png = audiomode.m_folders[rightmost_album] + "/track.png";

        album_covers[cover_count - 1].file_name = track_jpg;
        if (album_covers[cover_count - 1].texture_width == 0) {
            album_covers[cover_count - 1].file_name = track_png;
        }
    }

    // Reset positions
    for (local i = 0; i < cover_count; i++) {
        album_covers[i].x = cover_x_positions[i];
        album_covers[i].to_x = cover_x_positions[i];
    }

    animating = false;
}

function update_arttest() {
    if (plugin_available && audiomode && current_album_selection < audiomode.m_folders.len()) {
        local track_jpg = audiomode.m_folders[current_album_selection] + "/track.jpg";
        local track_png = audiomode.m_folders[current_album_selection] + "/track.png";

        arttest.file_name = track_jpg;
        if (arttest.texture_width == 0) {
            arttest.file_name = track_png;
        }
    } else {
        arttest.file_name = "";
    }
}

//==============================================
// CONTINUOUS MOVEMENT HANDLER
//==============================================
local last_move_time = 0;
local move_delay = 350;

//==============================================
// INITIALIZE - LOAD SONGS AND RESTORE STATE
//==============================================
load_all_song_lists();

current_album_selection = fe.nv.jukebox_last_album;
if (current_album_selection >= total_albums && total_albums > 0) {
    current_album_selection = 0;
} else if (total_albums == 0) {
    current_album_selection = 0;
}

current_song_selection = fe.nv.jukebox_last_song;

if (plugin_available && audiomode && current_album_selection in album_to_folder_map) {
    local folder_index = album_to_folder_map[current_album_selection];
    if (folder_index >= 0 && folder_index != audiomode.get_current_folder()) {
        fe.log("Startup: Restoring last album - switching to folder " + folder_index);
        audiomode.switch_to_folder(folder_index);
        fe.nv.jukebox_last_folder = folder_index;
    }
}

update_car_display();
update_arttest();
if (plugin_available) {
    update_coverflow_full();
}
load_initial_volume();

fe.log("Classic Car layout loaded successfully - Plugin available: " + plugin_available);

//==============================================
// SIGNAL HANDLER
//==============================================
fe.add_signal_handler("car_signal");

function car_signal(signal) {
    // CRITICAL: Never block exit or layout change signals
    if (signal == "exit_to_menu" || signal == "exit_game" || 
        signal == "prev_layout" || signal == "next_layout") {
        return false;
    }

    if (!plugin_available) {
        // When plugin not available, handle basic signals
        if (signal == "custom4") {
            active_mode = (active_mode == 1) ? 0 : 1;
            if (active_mode == 0) {
                album_text.alpha = 255;
                track_text.alpha = 50;
            } else {
                album_text.alpha = 50;
                track_text.alpha = 255;
            }
            return true;
        }
        // Block navigation but NOT exit signals
        if (signal == "left" || signal == "right" || signal == "up" || signal == "down" || signal == "select") {
            return true;
        }
        return false;
    }

    if (signal == "custom4" && active_mode == 1) {
        active_mode = 0;
        album_text.alpha = 255;
        track_text.alpha = 50;

        arttest.y = 900;
        arttest.delay_alpha = 600;
        arttest.time_alpha = 50;
        arttest.alpha = 255;
        arttest.to_alpha = 0;
        arttest.width = 600;
        arttest.to_width = 700;
        arttest.y = 600;
        arttest.to_y = 850;
        arttest.height = 250;
        arttest.to_height = 350;

        for (local i = 0; i < cover_count; i++) {
            album_covers[i].delay_alpha = 300;
            album_covers[i].alpha = 0;
            album_covers[i].to_alpha = 255;
        }

        update_car_display();
        update_coverflow_full();
        return true;
    }

    if (active_mode == 0) {
        // ALBUM MODE
        if (signal == "select") {
            if (!plugin_available || !audiomode) {
                fe.log("ERROR: Cannot select album - AudioMode_xtra not available");
                return true;
            }

            album_text.alpha = 50;
            track_text.alpha = 255;

            arttest.width = 700;
            arttest.to_width = 600;
            arttest.alpha = 255;
            arttest.y = 850;
            arttest.to_y = 600;
            arttest.height = 350;
            arttest.to_height = 250;

            for (local i = 0; i < cover_count; i++) {
                album_covers[i].alpha = 0;
            }

            local folder_index = -1;
            if (current_album_selection in album_to_folder_map) {
                folder_index = album_to_folder_map[current_album_selection];
            }

            if (folder_index >= 0) {
                if (folder_index != audiomode.get_current_folder()) {
                    audiomode.switch_to_folder(folder_index);
                    fe.nv.jukebox_last_folder = folder_index;
                }

                current_song_selection = 0;
                if (album_song_lists[current_album_selection].len() > 0) {
                    audiomode.m_index = 0;
                    audiomode.change_track(0);
                }

                active_mode = 1;
                fe.nv.jukebox_last_song = 0;
                update_car_display();
                update_arttest();
            }
            return true;
        } else if (signal == "left") {
            // CRITICAL FIX: Block input if still animating
            if (animating || total_albums == 0) return true;

            current_album_selection--;
            if (current_album_selection < 0) {
                current_album_selection = total_albums - 1;
            }
            fe.nv.jukebox_last_album = current_album_selection;
            update_car_display();
            last_direction = "left";
            last_move_time = fe.layout.time;
            update_coverflow_left();
            return true;
        } else if (signal == "right") {
            // CRITICAL FIX: Block input if still animating
            if (animating || total_albums == 0) return true;

            current_album_selection++;
            if (current_album_selection >= total_albums) {
                current_album_selection = 0;
            }
            fe.nv.jukebox_last_album = current_album_selection;
            update_car_display();
            last_direction = "right";
            last_move_time = fe.layout.time;
            update_coverflow_right();
            return true;
        } else if (signal == "up" || signal == "down") {
            return true;
        }
    } else {
        // SONG MODE
        if (!plugin_available || !audiomode) {
            return true;
        }

        local current_album_songs = album_song_lists[current_album_selection];
        if (current_album_songs.len() == 0) return false;

        if (signal == "left") {
            current_song_selection--;
            if (current_song_selection < 0) {
                current_song_selection = current_album_songs.len() - 1;
            }
            fe.nv.jukebox_last_song = current_song_selection;

            if (audiomode.m_index != null) {
                audiomode.m_index = current_song_selection;
                audiomode.change_track(0);
            }

            update_car_display();
            return true;
        } else if (signal == "right") {
            current_song_selection++;
            if (current_song_selection >= current_album_songs.len()) {
                current_song_selection = 0;
            }
            fe.nv.jukebox_last_song = current_song_selection;

            if (audiomode.m_index != null) {
                audiomode.m_index = current_song_selection;
                audiomode.change_track(0);
            }

            update_car_display();
            return true;
        } else if (signal == "up" || signal == "down") {
            return true;
        }
    }

    return false;
}

//==============================================
// TICK CALLBACK
//==============================================
local last_check = 0;

fe.add_ticks_callback("jukebox_tick");
function jukebox_tick(ttime) {
    // CONTINUOUS ALBUM NAVIGATION IN ALBUM MODE
    if (active_mode == 0 && !animating && plugin_available && total_albums > 0) {
        if (fe.get_input_state("left")) {
            if (ttime - last_move_time > move_delay) {
                current_album_selection--;
                if (current_album_selection < 0) {
                    current_album_selection = total_albums - 1;
                }
                fe.nv.jukebox_last_album = current_album_selection;
                update_car_display();
                last_direction = "left";
                last_move_time = ttime;
                update_coverflow_left();
            }
        } else if (fe.get_input_state("right")) {
            if (ttime - last_move_time > move_delay) {
                current_album_selection++;
                if (current_album_selection >= total_albums) {
                    current_album_selection = 0;
                }
                fe.nv.jukebox_last_album = current_album_selection;
                update_car_display();
                last_direction = "right";
                last_move_time = ttime;
                update_coverflow_right();
            }
        }
    }

    // Handle coverflow animation completion
    if (animating && ttime - animate_timer > 550) {
        if (last_direction == "left") {
            complete_coverflow_left();
        } else if (last_direction == "right") {
            complete_coverflow_right();
        }
    }

    local downState = fe.get_input_state("custom2");
    local upState = fe.get_input_state("custom1");

    if (ttime - lastVolumeChangeTime >= volumeChangeInterval) {
        if (downState && fe.ambient_sound.volume > 0) {
            adjust_volume(-volumeStep);
            lastVolumeChangeTime = ttime;
        } else if (upState && fe.ambient_sound.volume < 100) {
            adjust_volume(volumeStep);
            lastVolumeChangeTime = ttime;
        }
    }

    if (show_volume_display && ttime - volume_display_time > volume_display_duration) {
        hide_volume();
    }

    local fftSum = 1.0;
    for (local i = 0; i < fe.ambient_sound.fft_bands; i++) {
        fftSum += fe.ambient_sound.fft[i];
    }

    local avgFFT = fftSum / fe.ambient_sound.fft_bands.tofloat();

    if (cfg["Visualizers"] == "Yes") {
        for (local i = 0; i < fe.ambient_sound.fft_bands; i++) {
            local barHeight = (fe.ambient_sound.fft[i] * dotsPerBar * 2.0).tointeger();
            if (barHeight > dotsPerBar) barHeight = dotsPerBar;

            for (local d = 0; d < dotsPerBar; d++) {
                if (d < barHeight) {
                    bars_m[i][d].alpha = 50;
                } else {
                    bars_m[i][d].alpha = 0;
                }
            }
        }
    }

    // Auto-sync with audiomode (only if plugin available)
    if (plugin_available && ttime - last_check > 1000) {
        if (audiomode && audiomode.m_index != null) {
            local audiomode_index = audiomode.m_index;

            if (audiomode_index != current_song_selection && audiomode_index >= 0) {
                local current_album_songs = album_song_lists[current_album_selection];
                if (audiomode_index < current_album_songs.len()) {
                    current_song_selection = audiomode_index;
                    update_car_display();
                    fe.nv.jukebox_last_song = current_song_selection;
                }
            }
        }
        last_check = ttime;
    }
}

local words = fe.add_image("Classic_car_Artwork/words.png");
local vol_guide = fe.add_image("Classic_car_Artwork/guideb.png", 1419, 195, 166, 166);
vol_guide.anchor = Anchor.Centre;
vol_guide.zorder = 500;













/*
class UserConfig {
    </ label="Visualizer", help="Visualizer On/Off", options="Yes,No", order=3 />
    Visualizers = "No";
}

cfg <- fe.get_config();

fe.layout.preserve_aspect_ratio = true;
fe.layout.width = 1920;
fe.layout.height = 1080;

fe.layout.width = 1920;
fe.layout.height = 1080;
local my_config = fe.get_config();

local flx = fe.layout.width;
local fly = fe.layout.height;
local flw = fe.layout.width;
local flh = fe.layout.height;

fe.load_module("fade");
fe.load_module("inertia");
fe.load_module("file");
fe.load_module("wheel");
fe.load_module("mask");

//==============================================
// MODE CONTROL & PLUGIN
//==============================================
local active_mode = 1; // Start with songs active

// Get reference to AudioMode_xtra plugin
local audiomode = null;
if ("AudioMode_xtra" in fe.plugin) {
    audiomode = fe.plugin["AudioMode_xtra"];
} else {
    fe.log("ERROR: AudioMode_xtra plugin not found!");
}

//==============================================
// ALBUM TO FOLDER MAPPING - AUTO-DETECT
//==============================================
local total_albums = 0;
if (audiomode && audiomode.m_folders) {
    total_albums = audiomode.m_folders.len();
}

local album_to_folder_map = {};
for (local i = 0; i < total_albums; i++) {
    album_to_folder_map[i] <- i;
}

local current_album_selection = 0;
local current_song_selection = 0;

//==============================================
// FOLDER STATE PERSISTENCE
//==============================================
if (!("jukebox_last_folder" in fe.nv)) {
    fe.nv.jukebox_last_folder <- 0;
}

if (!("jukebox_last_album" in fe.nv)) {
    fe.nv.jukebox_last_album <- 0;
}

if (!("jukebox_last_song" in fe.nv)) {
    fe.nv.jukebox_last_song <- 0;
}

//==============================================
// SONG LISTS - LOAD DATA
//==============================================
local album_song_lists = [];
local album_display_names = [];

function load_all_song_lists() {
    album_song_lists = [];
    album_display_names = [];

    if (!audiomode) {
        fe.log("AudioMode_xtra not available for loading songs");
        return;
    }

    for (local album_idx = 0; album_idx < total_albums; album_idx++) {
        local folder_idx = album_to_folder_map[album_idx];

        if (folder_idx < audiomode.m_folders.len()) {
            local folder_path = audiomode.m_folders[folder_idx];
            local dir = DirectoryListing(folder_path);

            local song_files = [];
            local display_names = [];

            foreach (filename in dir.results) {
                local lower_filename = filename.tolower();
                if (lower_filename.find(".jpg") != null || lower_filename.find(".jpeg") != null || lower_filename.find(".png") != null || lower_filename.find(".gif") != null || lower_filename.find(".bmp") != null) {
                    continue;
                }

                song_files.push(filename);

                local display_name = filename;
                local parts = split(filename, "/\\");
                if (parts.len() > 0) {
                    display_name = parts[parts.len() - 1];
                    local dot_pos = display_name.find(".", display_name.len() - 5);
                    if (dot_pos != null) {
                        display_name = display_name.slice(0, dot_pos);
                    }
                }
                display_names.push(display_name);
            }

            album_song_lists.push(song_files);
            album_display_names.push(display_names);
            fe.log("Album " + album_idx + ": Loaded " + song_files.len() + " songs");
        } else {
            album_song_lists.push([]);
            album_display_names.push([]);
        }
    }
}

//==============================================
// ALBUM ART DISPLAY
//==============================================
local album_art = fe.add_image("", 399, 774, 318, 318);
album_art.anchor = Anchor.Centre;

local Etrack_top = fe.add_image("Classic_car_Artwork/8track_top3.png");
local Rtrack_bottom = fe.add_image("Classic_car_Artwork/8track_bottom3.png");

local vissurf = fe.add_surface(1030, 14, 700, 500);
local VW = 560;
local VH = 300;
vissurf.anchor = Anchor.Centre;
vissurf.zorder = 500;
//vissurf.alpha = 255;
fe.ambient_sound.fft_bands = 30;

//==============================================
// VOLUME CONTROL
//==============================================
local show_volume_display = true;
local volume_display_time = 0;
local volume_display_duration = 3000;

// Volume bars in a circle
local numBars = 25;
local barWidth = 13;
local barHeight = 10;
local circleRadius = 82;

local volumeBars = [];

//==============================================
//MARK: CREATE VOLUME BARS
//==============================================
for (local i = 0; i < numBars; i++) {
    local angleRange = 256.0;
    local angle = (i / (numBars - 1).tofloat()) * angleRange;
    angle = angle - -142;

    local angleRad = (angle * PI) / 180.0;

    local xPos = 1425 + cos(angleRad) * circleRadius;
    local yPos = 199 + sin(angleRad) * circleRadius;

    local rect = fe.add_rectangle(xPos, yPos, barWidth, barHeight);
    rect.set_rgb(255, 0, 0);
    rect.anchor = Anchor.Centre;
    rect.rotation = angle + 90;
    rect.alpha = 250; // Start dim

    rect.zorder = 500;
    volumeBars.append(rect);
}

//==============================================
// ALBUM & TRACK DISPLAY
//==============================================
local album_text = fe.add_text("", 720, 120, 550, 60);
album_text.font = "displdts.ttf";
album_text.charsize = 30;
album_text.set_rgb(255, 255, 255);
album_text.align = Align.MiddleLeft;
album_text.alpha = 50;
local track_text = fe.add_text("", 720, 180, 550, 60);
track_text.font = "displdts.ttf";
track_text.charsize = 30;
track_text.set_rgb(255, 255, 255);
track_text.align = Align.MiddleLeft;

//==============================================
// UPDATE DISPLAY FUNCTION
//==============================================
function update_car_display() {
    // Album: "1: Album Name"
    local album_num = current_album_selection + 1;
    local album_name = "";
    if (audiomode && current_album_selection < audiomode.m_folders.len()) {
        album_name = audiomode.get_folder_name(current_album_selection);

        // Load album art - try jpg first, then png
        local cover_jpg = audiomode.m_folders[current_album_selection] + "/cover.jpg";
        local cover_png = audiomode.m_folders[current_album_selection] + "/cover.png";

        // Try to load jpg first
        album_art.file_name = cover_jpg;

        // If jpg doesn't exist, try png
        if (album_art.texture_width == 0) {
            album_art.file_name = cover_png;
        }
    }
    album_text.msg = (album_num + ": " + album_name).toupper();
    album_art.alpha = 0;
    // Update album number image
    //update_album_number_display();

    // Track: Just the track name (already has number in filename)
    local track_name = "";
    if (current_album_selection < album_display_names.len() && current_song_selection < album_display_names[current_album_selection].len()) {
        track_name = album_display_names[current_album_selection][current_song_selection];
    }
    track_text.msg = track_name.toupper();
}

local vol_button = fe.add_image("Classic_car_Artwork/vol_button.png", 1419, 195, 138, 138);
vol_button.anchor = Anchor.Centre;
vol_button.rotation_origin_x = 0.5;
vol_button.rotation_origin_y = 0.5;
vol_button.rotation = -40;
//vol_button.alpha = 0;

local w = VW.tofloat() / fe.ambient_sound.fft_bands;

// Dot matrix settings
local dotSize = 8; // Size of each dot
local dotSpacing = 2; // Space between dots
local dotsPerBar = 14; // Number of dots vertically per bar

local bars_m = [];

// Create dot matrix bars
for (local i = 0; i < fe.ambient_sound.fft_bands; i++) {
    local barDots = []; // Array to hold all dots for this bar

    // Create vertical stack of dots for this bar
    for (local d = 0; d < dotsPerBar; d++) {
        local xPos = i * w;
        local yPos = 500 - d * (dotSize + dotSpacing); // Start from bottom

        local dot = vissurf.add_rectangle(xPos, yPos, dotSize, dotSize);

        dot.set_rgb(139, 140, 142);
        dot.alpha = 0; // Start invisible
        //dot.corner_ratio = 0.5; // Make dots circular

        barDots.append(dot);
    }

    bars_m.push(barDots); // Store array of dots for this bar
}
//==============================================
//MARK: VOLUME FUNCTIONS
//==============================================
function load_initial_volume() {
    local vol = "ambient_volume" in fe.nv ? fe.nv.ambient_volume : 50;

    // Set the actual volume to match saved value
    fe.ambient_sound.volume = vol;

    // Rotate button based on volume (0-270 degrees)
    vol_button.rotation = (vol / 100.0) * 270.0;

    //vol_word.rotation = (vol / 100.0) * 270.0;

    // Update bars
    local activeBars = floor(vol / (100.0 / numBars));
    fe.log("Setting " + activeBars + " bars active out of " + numBars);

    for (local i = 0; i < numBars; i++) {
        volumeBars[i].alpha = i < activeBars ? 255 : 0; //////////////////////////////////////
    }

    fe.log("Initial volume loaded: " + vol);
}

function show_volume(vol) {
    show_volume_display = true;
    volume_display_time = fe.layout.time;

    // Rotate button
    vol_button.rotation = (vol / 100.0) * 270.0;

    // Update bars
    local activeBars = floor(vol / (100.0 / numBars));
    for (local i = 0; i < numBars; i++) {
        volumeBars[i].alpha = i < activeBars ? 255 : 0; ///////////////////////////////////
    }
}

function hide_volume() {
    show_volume_display = false;
}

function adjust_volume(amount) {
    local v = fe.ambient_sound.volume + amount;
    if (v < 0) v = 0;
    if (v > 100) v = 100;

    fe.ambient_sound.volume = v;
    fe.nv.ambient_volume = v;

    show_volume(v);
}

//MARK: Continuous volume control
local volumeStep = 4;
local volumeChangeInterval = 200;
local lastVolumeChangeTime = 0;

//==============================================
// INITIALIZE - LOAD SONGS AND RESTORE STATE
//==============================================
load_all_song_lists();

current_album_selection = fe.nv.jukebox_last_album;
if (current_album_selection >= total_albums) current_album_selection = 0;

current_song_selection = fe.nv.jukebox_last_song;

// Sync AudioMode_xtra to remembered album
if (audiomode && current_album_selection in album_to_folder_map) {
    local folder_index = album_to_folder_map[current_album_selection];
    if (folder_index >= 0 && folder_index != audiomode.get_current_folder()) {
        fe.log("Startup: Restoring last album - switching to folder " + folder_index);
        audiomode.switch_to_folder(folder_index);
        fe.nv.jukebox_last_folder = folder_index;
    }
}

update_car_display();
load_initial_volume();

fe.log("Car layout loaded successfully");

local arttest = fe.add_artwork("8track", 965, 600, 600, 250); //1000,740,340,400
arttest.transform_origin = Origin.Centre;
// arttest.pinch_x=-100

local Etrack_middle = fe.add_image("Classic_car_Artwork/8track_middle3.png");

local retro = {
    init = function () {
        slots <- 9;
        speed <- 500;   
        artwork_label <- "8track";
        video_flags <- Vid.ImagesOnly;
        x <- 5;
        y <- 310;
        layout.y <- [ 540, 540, 540, 540, 540, 540, 540, 540, 540 ];
        layout.x <- [ -1140, -1140, -440, 260, 960, 1660, 2360, 3060, 3060 ];
        layout.width <- [ 700, 700, 700, 700, 700, 700, 700, 700, 700 ];
        layout.height <- [ 350, 350, 350, 350, 350, 350, 350, 350, 350 ];
        layout.alpha <- [ 255, 255, 255, 255, 255, 255, 255, 255, 255 ];
        //layout.pinch_x <- [ -100, -100, -100, -100, -100, -100, -100, -100, -100 ];
        layout.zorder <- [ 1, 1, 1, 1, 1, 1, 1, 1, 1 ];
        zorder <- 2;
        anchor <- Wheel.Anchor.Centre;
    }
};

local wheel = fe.add_wheel(retro);
wheel.alpha = 0;

arttest = Inertia(arttest, 500, "alpha", "pinch_x", "y", "height", "width");
wheel = Inertia(wheel, 500, "alpha");

//==============================================
// SIGNAL HANDLER
//==============================================
fe.add_signal_handler("car_signal");

function car_signal(signal) {
    if (signal == "custom4" && active_mode == 1) {
        active_mode = 0;
        album_text.alpha = 255;
        track_text.alpha = 50;

        arttest.y = 900;
        arttest.delay_alpha = 600;
        arttest.time_alpha = 50;
        arttest.alpha = 255;
        arttest.to_alpha = 0;

        arttest.width = 600;
        arttest.to_width = 700;

        arttest.y = 600;
        arttest.to_y = 850;
        arttest.height = 250;
        arttest.to_height = 350;

        wheel.delay_alpha = 300;
        wheel.alpha = 0;
        wheel.to_alpha = 255;
        update_car_display();
        return true;
    }

    if (active_mode == 0) {
        // ALBUM MODE
        if (signal == "select") {
            album_text.alpha = 50;
            track_text.alpha = 255;

            arttest.width = 700;
            arttest.to_width = 600;
            arttest.alpha = 255;
            arttest.y = 850;
            arttest.to_y = 600;
            arttest.height = 350;
            arttest.to_height = 250;
            wheel.alpha = 0;
            local folder_index = -1;
            if (current_album_selection in album_to_folder_map) {
                folder_index = album_to_folder_map[current_album_selection];
            }

            if (folder_index >= 0 && audiomode) {
                if (folder_index != audiomode.get_current_folder()) {
                    audiomode.switch_to_folder(folder_index);
                    fe.nv.jukebox_last_folder = folder_index;
                }

                current_song_selection = 0;
                if (album_song_lists[current_album_selection].len() > 0) {
                    audiomode.m_index = 0;
                    audiomode.change_track(0);
                }

                active_mode = 1;
                fe.nv.jukebox_last_song = 0;
                update_car_display();
            }
            return true;
        } else if (signal == "left") {
            current_album_selection--;
            if (current_album_selection < 0) {
                current_album_selection = total_albums - 1;
            }
            fe.nv.jukebox_last_album = current_album_selection;
            update_car_display();
            // Don't return true - let it fall through to move the wheel
        } else if (signal == "right") {
            current_album_selection++;
            if (current_album_selection >= total_albums) {
                current_album_selection = 0;
            }
            fe.nv.jukebox_last_album = current_album_selection;
            update_car_display();
            // Don't return true - let it fall through to move the wheel
        } else if (signal == "up" || signal == "down") {
            // Block up/down from moving the wheel
            return true;
        }
    } else {
        // SONG MODE
        local current_album_songs = album_song_lists[current_album_selection];
        if (current_album_songs.len() == 0) return false;

        if (signal == "left") {
            current_song_selection--;
            if (current_song_selection < 0) {
                current_song_selection = current_album_songs.len() - 1;
            }
            fe.nv.jukebox_last_song = current_song_selection;

            if (audiomode && audiomode.m_index != null) {
                audiomode.m_index = current_song_selection;
                audiomode.change_track(0);
            }

            update_car_display();
            return true;
        } else if (signal == "right") {
            current_song_selection++;
            if (current_song_selection >= current_album_songs.len()) {
                current_song_selection = 0;
            }
            fe.nv.jukebox_last_song = current_song_selection;

            if (audiomode && audiomode.m_index != null) {
                audiomode.m_index = current_song_selection;
                audiomode.change_track(0);
            }

            update_car_display();
            return true;
        } else if (signal == "up" || signal == "down") {
            // Block up/down in song mode too
            return true;
        }
    }

    // Let unhandled signals fall through to default handlers (which moves the wheel)
    return false;
}

//==============================================
// TICK CALLBACK
//==============================================
local last_check = 0;

fe.add_ticks_callback("jukebox_tick");
function jukebox_tick(ttime) {
    // CONTINUOUS VOLUME CONTROL
    local downState = fe.get_input_state("custom2");
    local upState = fe.get_input_state("custom1");

    if (ttime - lastVolumeChangeTime >= volumeChangeInterval) {
        if (downState && fe.ambient_sound.volume > 0) {
            adjust_volume(-volumeStep);
            lastVolumeChangeTime = ttime;
        } else if (upState && fe.ambient_sound.volume < 100) {
            adjust_volume(volumeStep);
            lastVolumeChangeTime = ttime;
        }
    }

    // Auto-hide volume display
    if (show_volume_display && ttime - volume_display_time > volume_display_duration) {
        hide_volume();
    }

    // CALCULATE FFT SUM FIRST
    local fftSum = 1.0;
    for (local i = 0; i < fe.ambient_sound.fft_bands; i++) {
        fftSum += fe.ambient_sound.fft[i];
    }

    local avgFFT = fftSum / fe.ambient_sound.fft_bands.tofloat();

    if (cfg["Visualizers"] == "Yes") {
        // MUSIC VISUALIZER UPDATE - DOT MATRIX
        for (local i = 0; i < fe.ambient_sound.fft_bands; i++) {
            // Calculate how many dots should be lit based on FFT value
            local barHeight = (fe.ambient_sound.fft[i] * dotsPerBar * 2.0).tointeger();
            if (barHeight > dotsPerBar) barHeight = dotsPerBar;

            // Light up dots from bottom to calculated height
            for (local d = 0; d < dotsPerBar; d++) {
                if (d < barHeight) {
                    bars_m[i][d].alpha = 50; // Lit
                } else {
                    bars_m[i][d].alpha = 0; // Dim
                }
            }
        }
    }
    // Auto-sync with audiomode
    if (ttime - last_check > 1000) {
        if (audiomode && audiomode.m_index != null) {
            local audiomode_index = audiomode.m_index;

            if (audiomode_index != current_song_selection && audiomode_index >= 0) {
                local current_album_songs = album_song_lists[current_album_selection];
                if (audiomode_index < current_album_songs.len()) {
                    current_song_selection = audiomode_index;
                    update_car_display();
                    fe.nv.jukebox_last_song = current_song_selection;
                }
            }
        }
        last_check = ttime;
    }
}

local words = fe.add_image("Classic_car_Artwork/words.png");
local vol_guide = fe.add_image("Classic_car_Artwork/guideb.png", 1419, 195, 166, 166);
vol_guide.anchor = Anchor.Centre;
vol_guide.zorder = 500;
*/
