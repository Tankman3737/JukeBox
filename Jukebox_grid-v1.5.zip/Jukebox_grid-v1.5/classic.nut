/**
 * Jukebox_grid - Classic
 *
 * @summary A short description.
 * @version 0.0.1 2026-1-9
 * @author Tankman3737
 * @url https://github.com/Tankman3737
 *
 * @requires
 * @module blur 0.1.0 https://github.com/Chadnaut/Attract-Mode-Modules
 * @module inertia 3.00 https://github.com/oomek/attract-extra
 * @module mask 0.3.1 https://github.com/Chadnaut/Attract-Mode-Modules
 * @module wheel 140.0 https://github.com/oomek/attract-extra
 */

fe.layout.width = 1920;
fe.layout.height = 1080;
local flw = fe.layout.width;
local flh = fe.layout.height;

local surfW = 695;
local surfH = 1020;
local surfX = 0;
local surfY = 0;

fe.layout.font = "verdana.ttf";
fe.load_module("wheel");
fe.load_module("inertia");
fe.load_module("mask");
fe.load_module("blur");

local theme_colours = {
    RED = [ [ 250, 0, 0 ] ],
    GREEN = [ [ 8, 255, 7 ] ],
    BLUE = [ [ 0, 0, 200 ] ],
    CYAN = [ [ 0, 90, 200 ] ],
    PURPLE = [ [ 74, 0, 134 ] ]
};

local selected = cfg["Wave_colour"];
local cols = theme_colours[selected];

//==============================================
// MODE CONTROL & PLUGIN - SAFE INITIALIZATION
//==============================================
local active_mode = 1; // Start with tracks active

// SAFE PLUGIN CHECK
local audiomode = null;
local plugin_available = false;

try {
    if ("AudioMode_xtra" in fe.plugin) {
        audiomode = fe.plugin["AudioMode_xtra"];
        plugin_available = true;
        fe.log("INFO: AudioMode_xtra plugin loaded successfully");
    } else {
        fe.log("WARNING: AudioMode_xtra plugin not found, running in limited mode");
    }
} catch (e) {
    fe.log("ERROR: Failed to check for AudioMode_xtra plugin: " + e);
    plugin_available = false;
}

//==============================================
// ALBUM TO FOLDER MAPPING - AUTO-DETECT
//==============================================
local total_albums = 0;
if (plugin_available && audiomode && audiomode.m_folders) {
    total_albums = audiomode.m_folders.len();
} else {
    fe.log("INFO: Running without AudioMode_xtra plugin, albums disabled");
}

local album_to_folder_map = {};
for (local i = 0; i < total_albums; i++) {
    album_to_folder_map[i] <- i;
}

local current_album_selection = 0;
local current_song_selection = 0;

// Add alpha values for dimming
local track_list_alpha = 255;
local album_list_alpha = 50;

//==============================================
// FOLDER STATE PERSISTENCE
//==============================================
if (!("jukebox_last_folder" in fe.nv)) {
    fe.nv.jukebox_last_folder <- 0;
}

if (!("jukebox_last_album" in fe.nv)) {
    fe.nv.jukebox_last_album <- 0;
}

if (!("jukebox_last_song" in fe.nv)) {
    fe.nv.jukebox_last_song <- 0;
}

//==============================================
// SONG LISTS - LOAD DATA
//==============================================
local album_song_lists = [];
local album_display_names = [];

function load_all_song_lists() {
    album_song_lists = [];
    album_display_names = [];

    if (!plugin_available || !audiomode) {
        fe.log("INFO: AudioMode_xtra not available, no songs loaded");
        // Add dummy data to prevent crashes
        album_song_lists.push([]);
        album_display_names.push(["Enable AudioMode_xtra Plugin"]);
        total_albums = 1;
        return;
    }

    for (local album_idx = 0; album_idx < total_albums; album_idx++) {
        local folder_idx = album_to_folder_map[album_idx];

        if (folder_idx < audiomode.m_folders.len()) {
            local folder_path = audiomode.m_folders[folder_idx];
            local dir = DirectoryListing(folder_path);

            local song_files = [];
            local display_names = [];

            foreach (filename in dir.results) {
                local lower_filename = filename.tolower();
                if (lower_filename.find(".jpg") != null || lower_filename.find(".jpeg") != null || lower_filename.find(".png") != null || lower_filename.find(".gif") != null || lower_filename.find(".bmp") != null) {
                    continue;
                }

                song_files.push(filename);

                local display_name = filename;
                local parts = split(filename, "/\\");
                if (parts.len() > 0) {
                    display_name = parts[parts.len() - 1];
                    local dot_pos = display_name.find(".", display_name.len() - 5);
                    if (dot_pos != null) {
                        display_name = display_name.slice(0, dot_pos);
                    }
                }
                display_names.push(display_name);
            }

            album_song_lists.push(song_files);
            album_display_names.push(display_names);
            fe.log("Album " + album_idx + ": Loaded " + song_files.len() + " songs");
        } else {
            album_song_lists.push([]);
            album_display_names.push([]);
        }
    }
}

local BG = fe.add_image("Classic_Artwork/win.png", 0, 0, 1920, 1080);
local vin = fe.add_image("Classic_Artwork/vin.png", 0, 0, 1920, 1080);
vin.alpha = 128;

local lower_drawBACK = fe.add_image("Classic_Artwork/lower_drawb2BACK.png", 0, 0, 1920, 1080);

local slideright = fe.add_surface(1920, 1080);
slideright.x = 345;
slideright.y = 0;

local sliderbottom = fe.add_surface(1920, 1080);
sliderbottom.x = 0;
sliderbottom.y = 0;

local Psurf = fe.add_surface(1920, 1080);
Psurf.x = 0;
Psurf.y = 0;

local side_draw = slideright.add_image("Classic_Artwork/side_drawb.png", 0, 0, 1920, 1080);

local pbar = fe.add_surface(400, 22);
pbar.x = 880;
pbar.y = 690;

local playerbar = pbar.add_image("Classic_Artwork/playbar.png", -380, 0, 400, 22);

//==============================================
// TRACK LIST (RIGHT SIDE)
//==============================================
local gamesurf = slideright.add_surface(310, 500);
gamesurf.x = 1050;
gamesurf.y = 167;

local rec = slideright.add_rectangle(1050, 363, 310, 30);
rec.set_rgb(0, 255, 0);
rec.alpha = 0;

// Create track list display (11 visible: -5 to +5)
local track_texts = [];

for (local i = -5; i <= 5; i++) {
    local txt = gamesurf.add_text("", 0, i * 40 + 200, 310, 20);
    txt.align = Align.Left;

    if (i == 0) {
        txt.set_rgb(0, 255, 0); // Highlight current
    }

    track_texts.append({ offset = i, text = txt });
}

function update_track_list() {
    if (current_album_selection >= album_song_lists.len()) return;

    local songs = album_display_names[current_album_selection];

    // Calculate scroll offset to keep current song centered
    local scroll_offset = current_song_selection - 5; // 5 is the middle position (offset 0)

    // Clamp scroll_offset so we don't show empty space at top or bottom
    if (scroll_offset < 0) scroll_offset = 0;
    if (scroll_offset + 11 > songs.len()) {
        scroll_offset = songs.len() - 11;
        if (scroll_offset < 0) scroll_offset = 0;
    }

    foreach (entry in track_texts) {
        local idx = scroll_offset + entry.offset + 5; // +5 because offset goes from -5 to +5

        if (idx >= 0 && idx < songs.len()) {
            entry.text.msg = songs[idx];

            // Highlight the current track
            if (idx == current_song_selection) {
                entry.text.set_rgb(0, 255, 0);
            } else {
                entry.text.set_rgb(255, 255, 255);
            }
        } else {
            entry.text.msg = "";
        }
    }
}

local BG_black = Psurf.add_image("Classic_Artwork/black.png", 600, 95, 720, 600);

local tests = Psurf.add_surface(610, 100, 695, 520);

// --- Helper to average bands over a range ---
function avg_fft(lo, hi) {
    local sum = 0.0;
    local count = 0;
    for (local i = lo; i <= hi && i < fe.ambient_sound.fft_bands; i++) {
        sum += fe.ambient_sound.fft[i];
        count++;
    }
    return count > 0 ? sum / count : 0.0;
}

//==============================================
// ALBUM LIST (BOTTOM - on sliderbottom)
//==============================================
local albumsurf = sliderbottom.add_surface(520, 245);
albumsurf.x = 740;
albumsurf.y = 755;

local album_highlight = albumsurf.add_rectangle(5, 90, 450, 35);
album_highlight.set_rgb(46, 146, 0);
album_highlight.alpha = 0;

// Create 7 album text entries (-3 to +3 offset)
local album_texts = [];
for (local i = -3; i <= 3; i++) {
    local yPos = 90 + i * 35;
    local txta = albumsurf.add_text("", 0, yPos, 500, 30);
    txta.align = Align.Left;
    txta.charsize = 18;
    //txta.alpha=50

    if (i == 0) {
        txta.set_rgb(0, 255, 0); // Highlight current
    }

    album_texts.append({ offset = i, text = txta });
}

function update_album_list() {
    foreach (entry in album_texts) {
        local idx = current_album_selection + entry.offset;

        if (plugin_available && audiomode && idx >= 0 && idx < total_albums) {
            local album_name = audiomode.get_folder_name(idx);
            entry.text.msg = album_name;
        } else {
            entry.text.msg = idx == current_album_selection ? "Please enable AudioMode_xtra Plugin" : "";
        }
    }
}

function update_mode_visibility() {
    if (active_mode == 0) {
        // Album mode active - dim tracks, brighten albums
        track_list_alpha = 50;
        album_list_alpha = 255;
        rec.alpha = 0; // Dim track highlight
        album_highlight.alpha = 0; // Bright album highlight
    } else {
        // Track mode active - brighten tracks, dim albums
        track_list_alpha = 255;
        album_list_alpha = 50;
        rec.alpha = 0; // Bright track highlight
        album_highlight.alpha = 0; // Dim album highlight
    }

    // Update track list alpha
    foreach (entry in track_texts) {
        entry.text.alpha = track_list_alpha;
    }

    // Update album list alpha
    foreach (entry in album_texts) {
        entry.text.alpha = album_list_alpha;
    }
}

//==============================================
// VISUALIZERS
//==============================================

//MARK: LED
if (cfg["Head_Space_Compact_Visualizer"] == "LED") {
    local LEDC = tests.add_surface(345, 255, 695, 530);
    LEDC.anchor = Anchor.Centre;

    LEDC.set_rgb(175, 170, 170);
    LEDC.shader = ::fe.add_shader(Shader.Fragment, "bump.frag");
    LEDC.shader.set_param("depth", 1.5);
    LEDC.shader.set_param("light1_rgba", 1.0, 0.0, 0.0, 1.0);
    LEDC.shader.set_param("light2_rgba", 0.0, 1.0, 0.0, 1.0);
    LEDC.shader.set_param("light3_rgba", 0.0, 0.0, 1.0, 1.0);
    LEDC.shader.set_param("light4_rgba", 1.0, 1.0, 0.0, 1.0);
    LEDC.shader.set_param("light5_rgba", 1.0, 0.0, 1.0, 1.0);
    LEDC.shader.set_param("light6_rgba", 0.0, 1.0, 1.0, 1.0);

    ::fe.add_transition_callback("on_transition_led");
    function on_transition_led(ttype, var, ttime) {
        switch (ttype) {
            case Transition.ToNewList:
            case Transition.FromOldSelection:
                LEDC.shader.set_param("texture_size", LEDC.texture_width, LEDC.texture_height);
                break;
        }
        return false;
    }

    ::fe.add_ticks_callback("on_tickscenter");
    function on_tickscenter(ttime) {
        local treb = avg_fft(11, fe.ambient_sound.fft_bands - 1);
        local t2 = fe.layout.time / 1000;

        local x = 0.5 + 0.5 * cos(t2 + treb * 5);
        local y = 0.5 + 0.5 * sin(t2 + treb * 5);
        LEDC.shader.set_param("light1_pos", x, y, 0.8);

        x = 0.5 + 0.5 * cos(t2 + 1.046 + treb * 5);
        y = 0.5 + 0.5 * sin(t2 + 1.046 + treb * 5);
        LEDC.shader.set_param("light2_pos", x, y, 0.8);

        x = 0.5 + 0.5 * cos(t2 + 2.092 + treb * 5);
        y = 0.5 + 0.5 * sin(t2 + 2.092 + treb * 5);
        LEDC.shader.set_param("light3_pos", x, y, 0.8);

        x = 0.5 + 0.5 * cos(t2 + 3.14 + treb * 5);
        y = 0.5 + 0.5 * sin(t2 + 3.14 + treb * 5);
        LEDC.shader.set_param("light4_pos", x, y, 0.8);

        x = 0.5 + 0.5 * cos(t2 + 4.184 + treb * 5);
        y = 0.5 + 0.5 * sin(t2 + 4.184 + treb * 5);
        LEDC.shader.set_param("light5_pos", x, y, 0.8);

        x = 0.5 + 0.5 * cos(t2 + 5.23 + treb * 5);
        y = 0.5 + 0.5 * sin(t2 + 5.23 + treb * 5);
        LEDC.shader.set_param("light6_pos", x, y, 0.8);
    }
}

if (cfg["Head_Space_Compact_Visualizer"] == "Waves") {
    local bg = tests.add_rectangle(surfX, surfY, surfW, surfH);
    bg.zorder = -100;

    switch (cfg["Wave_colour"]) {
        case "GREEN":
            bg.set_rgb(1, 100, 21);
            break;
        case "RED":
            bg.set_rgb(134, 0, 0);
            break;
        case "BLUE":
            bg.set_rgb(0, 8, 98);
            break;
        case "CYAN":
            bg.set_rgb(91, 109, 126);
            break;
        case "PURPLE":
            bg.set_rgb(134, 0, 69);
            break;
    }

    local background = tests.add_surface(surfW, surfH);
    background.blend_mode = BlendMode.Overlay;
    background.x = surfX;
    background.y = surfY;
    background.zorder = -90;

    local bgshader = fe.add_shader(Shader.Fragment, "play2.frag");
    bgshader.set_param("resolution", background.width.tofloat(), background.height.tofloat());
    bgshader.set_param("surfacePos", surfX.tofloat(), surfY.tofloat());
    background.shader = bgshader;

    local audioSmooth = 0.0;
    local shaderTime = 0.0;
    local vScale = 0.2;

    fe.add_ticks_callback("updateShader");
    function updateShader(ttime) {
        shaderTime = fe.layout.time;
        local val = fe.ambient_sound.fft.len() > 5 ? fe.ambient_sound.fft[5] : 0.0;
        audioSmooth = audioSmooth * 0.9 + val * 0.2;

        bgshader.set_param("resolution", background.width.tofloat(), background.height.tofloat());
        bgshader.set_param("surfacePos", background.x.tofloat(), background.y.tofloat());
        bgshader.set_param("ttime", shaderTime);
        bgshader.set_param("iAudio", audioSmooth);
        bgshader.set_param("vScale", vScale);
        bgshader.set_param("centerPoint", 0.5, 0.2);
    }

    if (cfg["led_overlay"] == "Yes") {
        local LEDunder = tests.add_surface(345, 255, 695, 530);
        LEDunder.anchor = Anchor.Centre;
        LEDunder.zorder = -95;

        LEDunder.set_rgb(175, 170, 170);
        LEDunder.shader = ::fe.add_shader(Shader.Fragment, "bump.frag");
        LEDunder.shader.set_param("depth", 1.5);
        LEDunder.shader.set_param("light1_rgba", 1.0, 0.0, 0.0, 1.0);
        LEDunder.shader.set_param("light2_rgba", 0.0, 1.0, 0.0, 1.0);
        LEDunder.shader.set_param("light3_rgba", 0.0, 0.0, 1.0, 1.0);
        LEDunder.shader.set_param("light4_rgba", 1.0, 1.0, 0.0, 1.0);
        LEDunder.shader.set_param("light5_rgba", 1.0, 0.0, 1.0, 1.0);
        LEDunder.shader.set_param("light6_rgba", 0.0, 1.0, 1.0, 1.0);

        fe.add_transition_callback("on_transition_waves");
        function on_transition_waves(ttype, var, ttime) {
            switch (ttype) {
                case Transition.ToNewList:
                case Transition.FromOldSelection:
                    LEDunder.shader.set_param("texture_size", LEDunder.texture_width, LEDunder.texture_height);
                    break;
            }
            return false;
        }

        fe.add_ticks_callback("on_tickunder");
        function on_tickunder(ttime) {
            local treb = avg_fft(11, fe.ambient_sound.fft_bands - 1);
            local t = fe.layout.time / 1000;

            local x = 0.5 + 0.5 * cos(t + treb * 5);
            local y = 0.5 + 0.5 * sin(t + treb * 5);
            LEDunder.shader.set_param("light1_pos", x, y, 0.8);

            x = 0.5 + 0.5 * cos(t + 1.046 + treb * 5);
            y = 0.5 + 0.5 * sin(t + 1.046 + treb * 5);
            LEDunder.shader.set_param("light2_pos", x, y, 0.8);

            x = 0.5 + 0.5 * cos(t + 2.092 + treb * 5);
            y = 0.5 + 0.5 * sin(t + 2.092 + treb * 5);
            LEDunder.shader.set_param("light3_pos", x, y, 0.8);

            x = 0.5 + 0.5 * cos(t + 3.14 + treb * 5);
            y = 0.5 + 0.5 * sin(t + 3.14 + treb * 5);
            LEDunder.shader.set_param("light4_pos", x, y, 0.8);

            x = 0.5 + 0.5 * cos(t + 4.184 + treb * 5);
            y = 0.5 + 0.5 * sin(t + 4.184 + treb * 5);
            LEDunder.shader.set_param("light5_pos", x, y, 0.8);

            x = 0.5 + 0.5 * cos(t + 5.23 + treb * 5);
            y = 0.5 + 0.5 * sin(t + 5.23 + treb * 5);
            LEDunder.shader.set_param("light6_pos", x, y, 0.8);
        }
    }
}

if (cfg["Head_Space_Compact_Visualizer"] == "Ripple") {
    local rippleSurf = tests.add_surface(200, 0, 800, 900);
    rippleSurf.anchor = Anchor.Centre;
    rippleSurf.zorder = 100;

    // Add album art behind ripple
    local ripple_album_art = tests.add_image("", 345, 260, 695, 520);
    ripple_album_art.anchor = Anchor.Centre;
    ripple_album_art.alpha = 200; // Slightly transparent
    ripple_album_art.zorder = 50; // Behind ripple effect

    local rippleShader = fe.add_shader(Shader.Fragment, "ripple.frag");
    rippleShader.set_param("resolution", surfW.tofloat(), surfH.tofloat());
    ripple_album_art.shader = rippleShader;

    local audioSmooth = 0.0;
    local shaderTime = 0.0;
    local vScale = 0.1;
    local useAudio = 1;
    rippleShader.set_param("useAudio", useAudio);

    fe.add_ticks_callback("updateRippleShader");
    function updateRippleShader(tt) {
        shaderTime += tt * 0.001;
        local val = 0.0;
        if (fe.ambient_sound.fft.len() > 5) val = fe.ambient_sound.fft[5];
        audioSmooth = audioSmooth * 0.2 + val * 0.1;

        rippleShader.set_param("ttime", shaderTime);
        rippleShader.set_param("iAudio", audioSmooth);
        rippleShader.set_param("vScale", vScale);
    }

    // Update album art function for ripple
    function update_ripple_album_art() {
        if (plugin_available && audiomode && current_album_selection < audiomode.m_folders.len()) {
            local cover_jpg = audiomode.m_folders[current_album_selection] + "/cover.jpg";
            local cover_png = audiomode.m_folders[current_album_selection] + "/cover.png";

            ripple_album_art.file_name = cover_jpg;
            if (ripple_album_art.texture_width == 0) {
                ripple_album_art.file_name = cover_png;
            }
        } else {
            ripple_album_art.file_name = "";
        }
    }
}

//MARK: BARS (DOT MATRIX)
if (cfg["Head_Space_Compact_Visualizer"] == "Bars") {
    local bars_surface = tests.add_surface(345, 260, 695, 520);
    bars_surface.anchor = Anchor.Centre;

    // Add album art behind bars
    local bars_album_art = bars_surface.add_image("", 347, 260, 695, 520);
    bars_album_art.anchor = Anchor.Centre;
    bars_album_art.alpha = 50; // Slightly transparent so bars show better

    fe.ambient_sound.fft_bands = 30;

    local numBands = fe.ambient_sound.fft_bands;
    local dotsPerBar = 15;
    local dotSize = 18;
    local dotSpacing = 2;
    local barWidth = 695.0 / numBands;

    local bars_m = [];

    // Create dot matrix bars
    for (local i = 0; i < numBands; i++) {
        local barDots = [];
        local xPos = i * barWidth + barWidth / 2 - dotSize / 2;

        for (local d = 0; d < dotsPerBar; d++) {
            local yPos = 520 - d * (dotSize + dotSpacing);

            local dot = bars_surface.add_rectangle(xPos, yPos, dotSize, dotSize);
            dot.set_rgb(cols[0][0], cols[0][1], cols[0][2]); // Use theme color
            dot.alpha = 50; // Dim by default
            dot.corner_ratio = 0.2;

            barDots.append(dot);
        }
        bars_m.push(barDots);
    }

    // Animate dots
    fe.add_ticks_callback("update_bars_dots");
    function update_bars_dots(ttime) {
        for (local i = 0; i < numBands; i++) {
            local barHeight = (fe.ambient_sound.fft[i] * dotsPerBar * 2.0).tointeger();
            if (barHeight > dotsPerBar) barHeight = dotsPerBar;

            for (local d = 0; d < dotsPerBar; d++) {
                if (d < barHeight) {
                    bars_m[i][d].alpha = 255; // Lit
                } else {
                    bars_m[i][d].alpha = 0; // Dim
                }
            }
        }
    }

    // Update album art function for bars
    function update_bars_album_art() {
        if (plugin_available && audiomode && current_album_selection < audiomode.m_folders.len()) {
            local cover_jpg = audiomode.m_folders[current_album_selection] + "/cover.jpg";
            local cover_png = audiomode.m_folders[current_album_selection] + "/cover.png";

            bars_album_art.file_name = cover_jpg;
            if (bars_album_art.texture_width == 0) {
                bars_album_art.file_name = cover_png;
            }
        } else {
            bars_album_art.file_name = "";
        }
    }
}
//MARK: ALBUM ART
local album_art = null;
if (cfg["Head_Space_Compact_Visualizer"] == "Album_Art") {
    album_art = tests.add_image("", 345, 260, 695, 520);
    album_art.anchor = Anchor.Centre;
}

function update_album_art() {
    if (album_art && plugin_available && audiomode && current_album_selection < audiomode.m_folders.len()) {
        local cover_jpg = audiomode.m_folders[current_album_selection] + "/cover.jpg";
        local cover_png = audiomode.m_folders[current_album_selection] + "/cover.png";

        album_art.file_name = cover_jpg;
        if (album_art.texture_width == 0) {
            album_art.file_name = cover_png;
        }
    } else if (album_art) {
        album_art.file_name = "";
    }
}

//==============================================
// TIME DISPLAY
//==============================================
local playtext2 = fe.add_text("", 1140, 635, 200, 20);
local playtext3 = fe.add_text("", 1140, 635, 100, 20);

fe.add_ticks_callback("on_tick_time");
function on_tick_time(ttime) {
    local currentTime = fe.ambient_sound.duration / 1000.0;
    local minutes = currentTime / 60;
    local seconds = currentTime % 60;
    playtext2.msg = format(" %d:%02d ", minutes, seconds);

    local currentTime2 = fe.ambient_sound.time / 1000.0;
    local minutes2 = currentTime2 / 60;
    local seconds2 = currentTime2 % 60;
    playtext3.msg = format(" %d:%02d ", minutes2, seconds2) + "/";
}

local black = Psurf.add_image("Classic_Artwork/current_black.png", 0, 0, 1920, 1080);

local current = Psurf.add_surface(500, 500);
current.x = 780;
current.y = 635;

local CSong = current.add_text("", 100, 0, 460, 20);
CSong.align = Align.Left;
CSong.set_rgb(0, 255, 0);

local current2 = Psurf.add_surface(500, 500);
current2.x = 850;
current2.y = 50;

local CSong2 = current2.add_text("", 0, 0, 600, 20);
CSong2.align = Align.Left;
CSong2.set_rgb(0, 255, 0);

function update_display() {
    update_track_list();
    update_album_list();
    update_mode_visibility();

    // CSong shows album name
    if (plugin_available && audiomode && current_album_selection < audiomode.m_folders.len()) {
        local album_name = audiomode.get_folder_name(current_album_selection);
        CSong.msg = album_name;
    } else {
        CSong.msg = "Plugin Not Available";
    }

    // CSong2 shows track name
    if (current_album_selection < album_display_names.len() && current_song_selection < album_display_names[current_album_selection].len()) {
        local track_name = album_display_names[current_album_selection][current_song_selection];
        CSong2.msg = track_name;
    } else {
        CSong2.msg = "No Track Available";
    }

    if (cfg["Head_Space_Compact_Visualizer"] == "Album_Art") {
        update_album_art();
    }

    if (cfg["Head_Space_Compact_Visualizer"] == "Bars") {
        update_bars_album_art();
    }

    if (cfg["Head_Space_Compact_Visualizer"] == "Ripple") {
        update_ripple_album_art();
    }
}

local player = Psurf.add_image("Classic_Artwork/timeplace.png", 0, 0, 1920, 1080);
local playerscreen = Psurf.add_image("Classic_Artwork/screenc.png", 0, 0, 1920, 1080);

//==============================================
// VOLUME CONTROL
//==============================================
local playerV = Psurf.add_image("Classic_Artwork/volumeslide.png", 995, 742, 25, 53);
playerV.anchor = Anchor.Centre;

function load_initial_volume() {
    local vol = "ambient_volume" in fe.nv ? fe.nv.ambient_volume : 50;
    fe.ambient_sound.volume = vol;

    local startX = 995;
    local stepSize = 11.5;
    local maxSteps = 5;
    local offset = (vol / 100.0) * (maxSteps * 2) - maxSteps;
    playerV.x = startX + offset * stepSize;
}

function adjust_volume(amount) {
    local v = fe.ambient_sound.volume + amount;
    if (v < 0) v = 0;
    if (v > 100) v = 100;

    fe.ambient_sound.volume = v;
    fe.nv.ambient_volume = v;

    local startX = 995;
    local stepSize = 11.5;
    local maxSteps = 5;
    local offset = (v / 100.0) * (maxSteps * 2) - maxSteps;
    playerV.to_x = startX + offset * stepSize;
}

local volumeStep = 5;
local volumeChangeInterval = 200;
local lastVolumeChangeTime = 0;

function continuousVolumeControl(ttime) {
    local downState = fe.get_input_state("custom2");
    local upState = fe.get_input_state("custom1");

    if (ttime - lastVolumeChangeTime >= volumeChangeInterval) {
        if (downState && fe.ambient_sound.volume > 0) {
            adjust_volume(-volumeStep);
            lastVolumeChangeTime = ttime;
        } else if (upState && fe.ambient_sound.volume < 100) {
            adjust_volume(volumeStep);
            lastVolumeChangeTime = ttime;
        }
    }
}
fe.add_ticks_callback("continuousVolumeControl");

local PB = Psurf.add_image("Classic_Artwork/Play_buttonb.png", 0, 0, 1920, 1080);

PB.alpha = 0;

local lower_draw = sliderbottom.add_image("Classic_Artwork/lower_drawb2.png", 0, 0, 1920, 1080);

//==============================================
// SPEAKER WITH LED SHADER
//==============================================
local Bigspeaker = fe.add_image("Classic_Artwork/Big_speaker.png", 250, 370, 400, 628);
Bigspeaker.anchor = Anchor.Centre;

local Bigspeakercone = fe.add_image("Classic_Artwork/Big_speaker_cone.png", 252, 455, 270, 270);
Bigspeakercone.anchor = Anchor.Centre;

local Bigspeakerconesmal = fe.add_image("Classic_Artwork/Big_speaker_conesmal.png", 253, 178, 80, 80);
Bigspeakerconesmal.anchor = Anchor.Centre;

local LEDspeaker = fe.add_image("Classic_Artwork/led2.png", 251, 452, 358, 358);
LEDspeaker.set_rgb(175, 170, 170);
LEDspeaker.anchor = Anchor.Centre;
LEDspeaker.shader = ::fe.add_shader(Shader.Fragment, "bump.frag");
LEDspeaker.shader.set_param("depth", 1.0);
LEDspeaker.shader.set_param("light1_rgba", 1.0, 0.0, 0.0, 1.0);
LEDspeaker.shader.set_param("light2_rgba", 0.0, 1.0, 0.0, 1.0);
LEDspeaker.shader.set_param("light3_rgba", 0.0, 0.0, 1.0, 1.0);
LEDspeaker.shader.set_param("light4_rgba", 1.0, 1.0, 0.0, 1.0);
LEDspeaker.shader.set_param("light5_rgba", 1.0, 0.0, 1.0, 1.0);
LEDspeaker.shader.set_param("light6_rgba", 0.0, 1.0, 1.0, 1.0);

::fe.add_transition_callback("on_transition_speaker");
function on_transition_speaker(ttype, var, ttime) {
    switch (ttype) {
        case Transition.ToNewList:
        case Transition.FromOldSelection:
            LEDspeaker.shader.set_param("texture_size", LEDspeaker.texture_width, LEDspeaker.texture_height);
            break;
    }
    return false;
}

::fe.add_ticks_callback("on_tickspeak");
function on_tickspeak(ttime) {
    local bass = avg_fft(0, 2);
    local treb = avg_fft(11, fe.ambient_sound.fft_bands - 1);

    Bigspeakerconesmal.width = 80 + treb * 20;
    Bigspeakerconesmal.height = 80 + treb * 20;

    Bigspeakercone.width = 270 + bass * 20;
    Bigspeakercone.height = 270 + bass * 20;

    local t = ttime / 1000.0;

    local x = 0.5 + 0.5 * cos(t + treb * 5);
    local y = 0.5 + 0.5 * sin(t + treb * 5);
    LEDspeaker.shader.set_param("light1_pos", x, y, 0.8);

    x = 0.5 + 0.5 * cos(t + 1.046 + treb * 5);
    y = 0.5 + 0.5 * sin(t + 1.046 + treb * 5);
    LEDspeaker.shader.set_param("light2_pos", x, y, 0.8);

    x = 0.5 + 0.5 * cos(t + 2.092 + treb * 5);
    y = 0.5 + 0.5 * sin(t + 2.092 + treb * 5);
    LEDspeaker.shader.set_param("light3_pos", x, y, 0.8);

    x = 0.5 + 0.5 * cos(t + 3.14 + treb * 5);
    y = 0.5 + 0.5 * sin(t + 3.14 + treb * 5);
    LEDspeaker.shader.set_param("light4_pos", x, y, 0.8);

    x = 0.5 + 0.5 * cos(t + 4.184 + treb * 5);
    y = 0.5 + 0.5 * sin(t + 4.184 + treb * 5);
    LEDspeaker.shader.set_param("light5_pos", x, y, 0.8);

    x = 0.5 + 0.5 * cos(t + 5.23 + treb * 5);
    y = 0.5 + 0.5 * sin(t + 5.23 + treb * 5);
    LEDspeaker.shader.set_param("light6_pos", x, y, 0.8);
}

//==============================================
// INERTIA & ANIMATIONS
//==============================================
PB = Inertia(PB, 500, "alpha");
CSong2 = Inertia(CSong2, 30000, "x");
CSong = Inertia(CSong, 20000, "x");
playerbar = Inertia(playerbar, "x");
sliderbottom = Inertia(sliderbottom, 1000, "y");
slideright = Inertia(slideright, 1000, "x", "y");
playerV = Inertia(playerV, 500, "x");

local last_track_file = "";

fe.add_ticks_callback("update_progress_bar");
function update_progress_bar(ttime) {
    local current_file = fe.ambient_sound.file_name;

    if (current_file != last_track_file && current_file.len() > 0) {
        last_track_file = current_file;

        playerbar.x = -380;
        playerbar.to_x = 0;
        playerbar.tween_x = Tween.Linear;
        playerbar.time_x = fe.ambient_sound.duration;
    }
}

function slideright_func(ttype, var, ttime) {
    if (ttype == Transition.StartLayout || ttype == Transition.ToNewList || ttype == Transition.EndNavigation) {
        PB.delay_alpha = 500;
        PB.alpha = 0;
        PB.to_alpha = 255;

        CSong.delay_x = 1500;
        CSong.tween_x = Tween.Linear;
        CSong.x = 50;
        CSong.to_x = -500;
        CSong.loop_x = true;

        CSong2.delay_x = 1500;
        CSong2.tween_x = Tween.Linear;
        CSong2.x = 150;
        CSong2.to_x = -500;
        CSong2.loop_x = true;

        playerbar.tween_x = Tween.Linear;
        playerbar.x = -380;
        playerbar.to_x = 1500;
        playerbar.time_x = fe.ambient_sound.duration;

        update_display();
    }

    if (ttype == Transition.ToNewSelection) {
        CSong.tween_x = Tween.Linear;
        CSong.x = 385;
        CSong.to_x = -500;
        CSong.loop_x = true;

        CSong2.delay_x = 1500;
        CSong2.tween_x = Tween.Linear;
        CSong2.x = 450;
        CSong2.to_x = -500;
        CSong2.loop_x = true;

        PB.alpha = 0;
        PB.to_alpha = 255;
    }

    return false;
}

fe.add_transition_callback("slideright_func");

//==============================================
// DATE & TIME
//==============================================
local dt = fe.add_text("", 1750, 1042, 120, 20);
dt.align = Align.Right;
dt.charsize = 12;
dt.set_rgb(255, 255, 255);
dt.alpha = 128;

function update_clock(ttime) {
    local now = date();

    if (now.hour == 0) {
        now.hour = 12;
        dt.msg = format("%02d", now.hour) + ":" + format("%02d", now.min) + " AM";
    } else if (now.hour < 12) {
        dt.msg = format("%02d", now.hour) + ":" + format("%02d", now.min) + " AM";
    } else if (now.hour == 12) {
        dt.msg = format("%02d", now.hour) + ":" + format("%02d", now.min) + " PM";
    } else {
        dt.msg = format("%02d", now.hour - 12) + ":" + format("%02d", now.min) + " PM";
    }

    return dt.msg;
}

fe.add_ticks_callback(this, "update_clock");

function updateTimestamp() {
    local months = [ "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" ];
    local now = date();
    return months[now.month + 0] + "/" + now.day + "/" + now.year;
}

local timestamp = fe.add_text("[!updateTimestamp]", 1758, 1060, 120, 20);
timestamp.align = Align.Right;
timestamp.charsize = 12;
timestamp.set_rgb(255, 255, 255);
timestamp.alpha = 128;

//==============================================
// INITIALIZE
//==============================================
load_all_song_lists();

current_album_selection = fe.nv.jukebox_last_album;
if (current_album_selection >= total_albums && total_albums > 0) {
    current_album_selection = 0;
} else if (total_albums == 0) {
    current_album_selection = 0;
}

current_song_selection = fe.nv.jukebox_last_song;

if (plugin_available && audiomode && current_album_selection in album_to_folder_map) {
    local folder_index = album_to_folder_map[current_album_selection];
    if (folder_index >= 0 && folder_index != audiomode.get_current_folder()) {
        audiomode.switch_to_folder(folder_index);
        fe.nv.jukebox_last_folder = folder_index;
    }
}

update_display();
load_initial_volume();

fe.log("Compact layout loaded successfully - Plugin available: " + plugin_available);

//==============================================
// SIGNAL HANDLER
//==============================================
fe.add_signal_handler("compact_signal");

function compact_signal(signal) {
    // CRITICAL: Never block exit or layout change signals
    if (signal == "exit_to_menu" || signal == "exit_game" || 
        signal == "prev_layout" || signal == "next_layout") {
        return false;
    }

    if (!plugin_available) {
        // When plugin not available, handle basic signals
        if (signal == "custom4") {
            active_mode = (active_mode == 1) ? 0 : 1;
            update_display();
            return true;
        }
        // Block navigation but NOT exit signals
        if (signal == "left" || signal == "right" || signal == "up" || signal == "down" || signal == "select") {
            return true;
        }
        return false;
    }

    if (signal == "custom4" && active_mode == 1) {
        active_mode = 0;

        update_display();
        return true;
    }

    if (active_mode == 0) {
        // ALBUM MODE
        if (signal == "select") {
            if (!plugin_available || !audiomode) {
                fe.log("ERROR: Cannot select album - AudioMode_xtra not available");
                return true;
            }

            local folder_index = -1;
            if (current_album_selection in album_to_folder_map) {
                folder_index = album_to_folder_map[current_album_selection];
            }

            if (folder_index >= 0) {
                if (folder_index != audiomode.get_current_folder()) {
                    audiomode.switch_to_folder(folder_index);
                    fe.nv.jukebox_last_folder = folder_index;
                }

                current_song_selection = 0;
                if (album_song_lists[current_album_selection].len() > 0) {
                    audiomode.m_index = 0;
                    audiomode.change_track(0);
                }

                active_mode = 1;
                fe.nv.jukebox_last_song = 0;
                update_display();
            }
            return true;
        } else if (signal == "up") {
            if (total_albums == 0) return true;

            current_album_selection--;
            if (current_album_selection < 0) {
                current_album_selection = total_albums - 1;
            }
            fe.nv.jukebox_last_album = current_album_selection;
            
            update_display();
            return true;
        } else if (signal == "down") {

    
            if (total_albums == 0) return true;

            current_album_selection++;
            if (current_album_selection >= total_albums) {
                current_album_selection = 0;
            }
            fe.nv.jukebox_last_album = current_album_selection;
            update_display();
            return true;
        }
    } else {
        // SONG MODE
        if (!plugin_available || !audiomode) {
            return true;
        }

        local current_album_songs = album_song_lists[current_album_selection];
        if (current_album_songs.len() == 0) return false;

        if (signal == "up") {
             PB.delay_alpha =300;
        PB.alpha = 0;
        PB.to_alpha = 255;
            current_song_selection--;
            if (current_song_selection < 0) {
                current_song_selection = current_album_songs.len() - 1;
            }
            fe.nv.jukebox_last_song = current_song_selection;

            if (audiomode.m_index != null) {
                audiomode.m_index = current_song_selection;
                audiomode.change_track(0);
            }

            update_display();
            return true;
        } else if (signal == "down") {
                  PB.delay_alpha =300;
        PB.alpha = 0;
        PB.to_alpha = 255;
            current_song_selection++;
            if (current_song_selection >= current_album_songs.len()) {
                current_song_selection = 0;
            }
            fe.nv.jukebox_last_song = current_song_selection;

            if (audiomode.m_index != null) {
                audiomode.m_index = current_song_selection;
                audiomode.change_track(0);
            }

            update_display();
            return true;
        }
    }

    if (signal == "up" || signal == "down" || signal == "left" || signal == "right" || signal == "select") {
        return false;
    }

    return false;
}

//==============================================
// TICK CALLBACK - AUTO-SYNC
//==============================================
local last_check = 0;

fe.add_ticks_callback("auto_sync");
function auto_sync(ttime) {
    // Auto-sync with audiomode (only if plugin available)
    if (plugin_available && ttime - last_check > 1000) {
        if (audiomode && audiomode.m_index != null) {
            local audiomode_index = audiomode.m_index;

            if (audiomode_index != current_song_selection && audiomode_index >= 0) {
                local current_album_songs = album_song_lists[current_album_selection];
                if (audiomode_index < current_album_songs.len()) {
                    current_song_selection = audiomode_index;
                    update_display();
                    fe.nv.jukebox_last_song = current_song_selection;
                }
            }
        }
        last_check = ttime;
    }
}

local words = fe.add_image("classic_artwork/words.png");