/**
 * Jukebox_grid - Car strero
 *
 * @summary A short description.
 * @version 0.0.1 2026-1-6
 * @author Tankman3737
 * @url https://github.com/Tankman3737
 *
 * @requires
 * @module fade (Included with AM)
 * @module file (Included with AM)
 * @module inertia 3.00 https://github.com/oomek/attract-extra
 * @module mask 0.3.1 https://github.com/Chadnaut/Attract-Mode-Modules
 */

fe.layout.width = 1920;
fe.layout.height = 1080;
local my_config = fe.get_config();

local flx = fe.layout.width;
local fly = fe.layout.height;
local flw = fe.layout.width;
local flh = fe.layout.height;

fe.load_module("fade");
fe.load_module("inertia");
fe.load_module("file");

fe.load_module("mask");

local theme_colours = {
    Red = [ [ 250, 0, 0 ] ],
    Green = [ [ 8, 255, 7 ] ],
    Blue = [ [ 0, 90, 200 ] ],
    Purple = [ [ 94, 0, 134 ] ]
};

local selected = cfg["color"];
local cols = theme_colours[selected];

//==============================================
// MODE CONTROL & PLUGIN - SAFE INITIALIZATION
//==============================================
local active_mode = 1; // Start with songs active

// SAFE PLUGIN CHECK
local audiomode = null;
local plugin_available = false;

try {
    if ("AudioMode_xtra" in fe.plugin) {
        audiomode = fe.plugin["AudioMode_xtra"];
        plugin_available = true;
        fe.log("INFO: AudioMode_xtra plugin loaded successfully");
    } else {
        fe.log("WARNING: AudioMode_xtra plugin not found, running in limited mode");
    }
} catch (e) {
    fe.log("ERROR: Failed to check for AudioMode_xtra plugin: " + e);
    plugin_available = false;
}

//==============================================
// ALBUM TO FOLDER MAPPING - AUTO-DETECT
//==============================================
local total_albums = 0;
if (plugin_available && audiomode && audiomode.m_folders) {
    total_albums = audiomode.m_folders.len();
} else {
    fe.log("INFO: Running without AudioMode_xtra plugin, albums disabled");
}

local album_to_folder_map = {};
for (local i = 0; i < total_albums; i++) {
    album_to_folder_map[i] <- i;
}

local current_album_selection = 0;
local current_song_selection = 0;

//==============================================
// FOLDER STATE PERSISTENCE
//==============================================
if (!("jukebox_last_folder" in fe.nv)) {
    fe.nv.jukebox_last_folder <- 0;
}

if (!("jukebox_last_album" in fe.nv)) {
    fe.nv.jukebox_last_album <- 0;
}

if (!("jukebox_last_song" in fe.nv)) {
    fe.nv.jukebox_last_song <- 0;
}

//==============================================
// SONG LISTS - LOAD DATA
//==============================================
local album_song_lists = [];
local album_display_names = [];

function load_all_song_lists() {
    album_song_lists = [];
    album_display_names = [];

    if (!plugin_available || !audiomode) {
        fe.log("INFO: AudioMode_xtra not available, no songs loaded");
        // Add dummy data to prevent crashes
        album_song_lists.push([]);
        album_display_names.push(["No Audio Plugin Available"]);
        total_albums = 1;
        return;
    }

    for (local album_idx = 0; album_idx < total_albums; album_idx++) {
        local folder_idx = album_to_folder_map[album_idx];

        if (folder_idx < audiomode.m_folders.len()) {
            local folder_path = audiomode.m_folders[folder_idx];
            local dir = DirectoryListing(folder_path);

            local song_files = [];
            local display_names = [];

            foreach (filename in dir.results) {
                local lower_filename = filename.tolower();
                if (lower_filename.find(".jpg") != null || lower_filename.find(".jpeg") != null || lower_filename.find(".png") != null || lower_filename.find(".gif") != null || lower_filename.find(".bmp") != null) {
                    continue;
                }

                song_files.push(filename);

                local display_name = filename;
                local parts = split(filename, "/\\");
                if (parts.len() > 0) {
                    display_name = parts[parts.len() - 1];
                    local dot_pos = display_name.find(".", display_name.len() - 5);
                    if (dot_pos != null) {
                        display_name = display_name.slice(0, dot_pos);
                    }
                }
                display_names.push(display_name);
            }

            album_song_lists.push(song_files);
            album_display_names.push(display_names);
            fe.log("Album " + album_idx + ": Loaded " + song_files.len() + " songs");
        } else {
            album_song_lists.push([]);
            album_display_names.push([]);
        }
    }
}

//==============================================
// ALBUM ART DISPLAY
//==============================================
local album_art = fe.add_image("", 399, 774, 318, 318);
album_art.anchor = Anchor.Centre;

local BG = fe.add_image("Stereo_Artwork/stereo_BG4.png", 0, 0, 1920, 1080);

local mask = ::fe.add_image("Stereo_Artwork/screen_mask.png");
mask.visible = false;
local art = Mask(fe.add_image("Stereo_Artwork/Carnewblur.mp4", 0, 0, 1920, 1080));
art.mask = mask;
art.alpha = 20;

local all_numbers = fe.add_image("Stereo_Artwork/all_numbers.png");

local album_numbers = [];

local num_1 = fe.add_image("Stereo_Artwork/1.png");
num_1.set_rgb(cols[0][0], cols[0][1], cols[0][2]);
num_1.visible = false;
album_numbers.append(num_1);

local num_2 = fe.add_image("Stereo_Artwork/2.png");
num_2.set_rgb(cols[0][0], cols[0][1], cols[0][2]);
num_2.visible = false;
album_numbers.append(num_2);

local num_3 = fe.add_image("Stereo_Artwork/3.png");
num_3.set_rgb(cols[0][0], cols[0][1], cols[0][2]);
num_3.visible = false;
album_numbers.append(num_3);

local num_4 = fe.add_image("Stereo_Artwork/4.png");
num_4.set_rgb(cols[0][0], cols[0][1], cols[0][2]);
num_4.visible = false;
album_numbers.append(num_4);

local num_5 = fe.add_image("Stereo_Artwork/5.png");
num_5.set_rgb(cols[0][0], cols[0][1], cols[0][2]);
num_5.visible = false;
album_numbers.append(num_5);

local num_6 = fe.add_image("Stereo_Artwork/6.png");
num_6.set_rgb(cols[0][0], cols[0][1], cols[0][2]);
num_6.visible = false;
album_numbers.append(num_6);

local num_7 = fe.add_image("Stereo_Artwork/7.png");
num_7.set_rgb(cols[0][0], cols[0][1], cols[0][2]);
num_7.visible = false;
album_numbers.append(num_7);

local num_8 = fe.add_image("Stereo_Artwork/8.png");
num_8.set_rgb(cols[0][0], cols[0][1], cols[0][2]);
num_8.visible = false;
album_numbers.append(num_8);

local num_9 = fe.add_image("Stereo_Artwork/9.png");
num_9.set_rgb(cols[0][0], cols[0][1], cols[0][2]);
num_9.visible = false;
album_numbers.append(num_9);

local num_10 = fe.add_image("Stereo_Artwork/10.png");
num_10.set_rgb(cols[0][0], cols[0][1], cols[0][2]);
num_10.visible = false;
album_numbers.append(num_10);

function update_album_number_display() {
    // Hide all numbers first
    foreach (num in album_numbers) {
        num.visible = false;
    }

    // Show the current album number (albums are 1-indexed for display)
    local album_num = current_album_selection + 1;
    if (album_num >= 1 && album_num <= album_numbers.len()) {
        album_numbers[album_num - 1].visible = true;
    }
}
//==============================================
// VOLUME CONTROL
//==============================================
local show_volume_display = false;
local volume_display_time = 0;
local volume_display_duration = 3000;

// Volume bars in a circle
local numBars = 25;
local barWidth = 28;
local barHeight = 18;
local circleRadius = 156;

local volumeBars = [];

//==============================================
//MARK: CREATE VOLUME BARS
//==============================================
for (local i = 0; i < numBars; i++) {
    local angleRange = 256.0;
    local angle = (i / (numBars - 1).tofloat()) * angleRange;
    angle = angle - -142;

    local angleRad = (angle * PI) / 180.0;

    local xPos = 973 + cos(angleRad) * circleRadius;
    local yPos = 783 + sin(angleRad) * circleRadius;

    local rect = fe.add_rectangle(xPos, yPos, barWidth, barHeight);
    rect.anchor = Anchor.Centre;
    rect.rotation = angle + 90;
    rect.alpha = 250; // Start dim

    rect.set_rgb(cols[0][0], cols[0][1], cols[0][2]);
    rect.zorder = 100;
    volumeBars.append(rect);
}

//==============================================
// ALBUM & TRACK DISPLAY
//==============================================
local album_text = fe.add_text("", 550, 220, 920, 60);
album_text.font = "displdts.ttf";
album_text.charsize = 60;
album_text.set_rgb(255, 255, 255);
album_text.align = Align.MiddleLeft;

local track_text = fe.add_text("", 550, 320, 920, 60);
track_text.font = "displdts.ttf";
track_text.charsize = 40;
track_text.set_rgb(255, 255, 255);
track_text.align = Align.MiddleLeft;

//==============================================
// UPDATE DISPLAY FUNCTION
//==============================================
function update_car_display() {
    // Album: "1: Album Name"
    local album_num = current_album_selection + 1;
    local album_name = "";
    
    if (plugin_available && audiomode && current_album_selection < audiomode.m_folders.len()) {
        album_name = audiomode.get_folder_name(current_album_selection);

        // Load album art - try jpg first, then png
        local cover_jpg = audiomode.m_folders[current_album_selection] + "/cover.jpg";
        local cover_png = audiomode.m_folders[current_album_selection] + "/cover.png";

        // Try to load jpg first
        album_art.file_name = cover_jpg;

        // If jpg doesn't exist, try png
        if (album_art.texture_width == 0) {
            album_art.file_name = cover_png;
        }
    } else {
        album_name = "Please enable ";
        album_art.file_name = "";
    }
    
    album_text.msg = (album_num + ": " + album_name).toupper();

    // Update album number image
    update_album_number_display();

    // Track: Just the track name (already has number in filename)
    local track_name = "";
    if (current_album_selection < album_display_names.len() && current_song_selection < album_display_names[current_album_selection].len()) {
        track_name = album_display_names[current_album_selection][current_song_selection];
    } else {
        track_name = "AudioMode_xtra plugin";
    }
    track_text.msg = track_name.toupper();
}

local side_bars_blur = fe.add_image("Stereo_Artwork/button_glow3.png");
side_bars_blur.set_rgb(cols[0][0], cols[0][1], cols[0][2]);

local buttons_glow = fe.add_image("Stereo_Artwork/button_glow2.png");
buttons_glow.set_rgb(cols[0][0], cols[0][1], cols[0][2]);

local play = fe.add_image("Stereo_Artwork/play_button2.png");

local side_bars_blur2 = fe.add_image("Stereo_Artwork/side_bars_blur2.png");
side_bars_blur2.set_rgb(cols[0][0], cols[0][1], cols[0][2]);

local side_bars_blur3 = fe.add_image("Stereo_Artwork/side_bars_blur.png");
side_bars_blur3.set_rgb(cols[0][0], cols[0][1], cols[0][2]);

local side_bars2 = fe.add_image("Stereo_Artwork/side_bars.png");

local vol_button = fe.add_image("Stereo_Artwork/vol_button4.png", 958, 775, 272, 272);
vol_button.anchor = Anchor.Centre;
vol_button.rotation_origin_x = 0.5;
vol_button.rotation_origin_y = 0.5;
vol_button.rotation = -40;

// local vol_word=fe.add_image("Stereo_Artwork/vol.png",959,774,180,100)
// vol_word.anchor = Anchor.Centre;
// vol_word.rotation_origin_x = 0.5;
// vol_word.rotation_origin_y = 0.5;
// vol_word.rotation = 0;
// vol_word.set_rgb(cols[0][0], cols[0][1], cols[0][2]);

local left_right = fe.add_image("Stereo_Artwork/L_Rarrows.png", 470, 200, 100, 100);
left_right.set_rgb(cols[0][0], cols[0][1], cols[0][2]);
left_right.alpha = 0;
local up_down = fe.add_image("Stereo_Artwork/U_Darrows.png", 470, 300, 100, 100);
up_down.set_rgb(cols[0][0], cols[0][1], cols[0][2]);

local buttons = fe.add_image("Stereo_Artwork/guide2.png", 0, 0, 1920, 1080);
buttons.zorder = 500;
buttons.set_rgb(cols[0][0], cols[0][1], cols[0][2]);

local words = fe.add_image("Stereo_Artwork/words_etc2.png");
words.set_rgb(cols[0][0], cols[0][1], cols[0][2]);
words.zorder = 500;

local vissurf = fe.add_surface(980, 334, 700, 500);
local VW = 700;
local VH = 500;
vissurf.anchor = Anchor.Centre;
vissurf.zorder = 10;

fe.ambient_sound.fft_bands = 30;

local w = VW.tofloat() / fe.ambient_sound.fft_bands;

// Dot matrix settings
local dotSize = 10; // Size of each dot
local dotSpacing = 2; // Space between dots
local dotsPerBar = 14; // Number of dots vertically per bar

local bars_m = [];

// Create dot matrix bars
for (local i = 0; i < fe.ambient_sound.fft_bands; i++) {
    local barDots = []; // Array to hold all dots for this bar

    // Create vertical stack of dots for this bar
    for (local d = 0; d < dotsPerBar; d++) {
        local xPos = i * w;
        local yPos = 500 - d * (dotSize + dotSpacing); // Start from bottom

        local dot = vissurf.add_rectangle(xPos, yPos, dotSize, dotSize);
        dot.set_rgb(cols[0][0], cols[0][1], cols[0][2]);
        dot.alpha = 0; // Start invisible
        //dot.corner_ratio = 0.5; // Make dots circular

        barDots.append(dot);
    }

    bars_m.push(barDots); // Store array of dots for this bar
}
//==============================================
// VOLUME FUNCTIONS
//==============================================
function load_initial_volume() {
    local vol = "ambient_volume" in fe.nv ? fe.nv.ambient_volume : 50;

    // Set the actual volume to match saved value
    fe.ambient_sound.volume = vol;

    // Rotate button based on volume (0-270 degrees)
    vol_button.rotation = (vol / 100.0) * 270.0;

    //vol_word.rotation = (vol / 100.0) * 270.0;

    // Update bars
    local activeBars = floor(vol / (100.0 / numBars));
    fe.log("Setting " + activeBars + " bars active out of " + numBars);

    for (local i = 0; i < numBars; i++) {
        volumeBars[i].alpha = i < activeBars ? 255 : 0;
    }

    fe.log("Initial volume loaded: " + vol);
}

function show_volume(vol) {
    show_volume_display = true;
    volume_display_time = fe.layout.time;

    // Rotate button
    vol_button.rotation = (vol / 100.0) * 270.0;
    //vol_word.rotation = (vol / 100.0) * 270.0;
    // Update bars
    local activeBars = floor(vol / (100.0 / numBars));
    for (local i = 0; i < numBars; i++) {
        volumeBars[i].alpha = i < activeBars ? 255 : 0;
    }
}

function hide_volume() {
    show_volume_display = false;
}

function adjust_volume(amount) {
    local v = fe.ambient_sound.volume + amount;
    if (v < 0) v = 0;
    if (v > 100) v = 100;

    fe.ambient_sound.volume = v;
    fe.nv.ambient_volume = v;

    show_volume(v);
}

//MARK: Continuous volume control
local volumeStep = 4;
local volumeChangeInterval = 200;
local lastVolumeChangeTime = 0;

//==============================================
// INITIALIZE - LOAD SONGS AND RESTORE STATE
//==============================================
load_all_song_lists();

current_album_selection = fe.nv.jukebox_last_album;
if (current_album_selection >= total_albums && total_albums > 0) {
    current_album_selection = 0;
} else if (total_albums == 0) {
    current_album_selection = 0;
}

current_song_selection = fe.nv.jukebox_last_song;

// Sync AudioMode_xtra to remembered album
if (plugin_available && audiomode && current_album_selection in album_to_folder_map) {
    local folder_index = album_to_folder_map[current_album_selection];
    if (folder_index >= 0 && folder_index != audiomode.get_current_folder()) {
        fe.log("Startup: Restoring last album - switching to folder " + folder_index);
        audiomode.switch_to_folder(folder_index);
        fe.nv.jukebox_last_folder = folder_index;
    }
}

update_car_display();
load_initial_volume();

fe.log("Car layout loaded successfully - Plugin available: " + plugin_available);

//==============================================
// SIGNAL HANDLER
//==============================================
fe.add_signal_handler("car_signal");

function car_signal(signal) {
    // CRITICAL: Never block exit or layout change signals
    if (signal == "exit_to_menu" || signal == "exit_game" || 
        signal == "prev_layout" || signal == "next_layout") {
        return false;
    }

    if (!plugin_available) {
        // When plugin not available, handle basic signals
        if (signal == "custom4") {
            active_mode = (active_mode == 1) ? 0 : 1;
            if (active_mode == 0) {
                up_down.alpha = 0;
                left_right.alpha = 255;
            } else {
                left_right.alpha = 0;
                up_down.alpha = 255;
            }
            return true;
        }
        // Block navigation but NOT exit signals
        if (signal == "left" || signal == "right" || signal == "up" || signal == "down" || signal == "select") {
            return true;
        }
        return false;
    }

    if (signal == "custom4" && active_mode == 1) {
        active_mode = 0;
        up_down.alpha = 0;
        left_right.alpha = 255;
        update_car_display();
        return true;
    }

    if (active_mode == 0) {
        // ALBUM MODE
        if (signal == "select") {
            if (!plugin_available || !audiomode) {
                fe.log("ERROR: Cannot select album - AudioMode_xtra not available");
                return true;
            }

            left_right.alpha = 0;
            up_down.alpha = 255;
            local folder_index = -1;
            if (current_album_selection in album_to_folder_map) {
                folder_index = album_to_folder_map[current_album_selection];
            }

            if (folder_index >= 0) {
                if (folder_index != audiomode.get_current_folder()) {
                    audiomode.switch_to_folder(folder_index);
                    fe.nv.jukebox_last_folder = folder_index;
                }

                current_song_selection = 0;
                if (album_song_lists[current_album_selection].len() > 0) {
                    audiomode.m_index = 0;
                    audiomode.change_track(0);
                }

                active_mode = 1;
                fe.nv.jukebox_last_song = 0;
                update_car_display();
            }
            return true;
        } else if (signal == "left") {
            if (total_albums == 0) return true;

            current_album_selection--;
            if (current_album_selection < 0) {
                current_album_selection = total_albums - 1;
            }
            fe.nv.jukebox_last_album = current_album_selection;
            update_car_display();
            return true;
        } else if (signal == "right") {
            if (total_albums == 0) return true;

            current_album_selection++;
            if (current_album_selection >= total_albums) {
                current_album_selection = 0;
            }
            fe.nv.jukebox_last_album = current_album_selection;
            update_car_display();
            return true;
        }
    } else {
        // SONG MODE
        if (!plugin_available || !audiomode) {
            return true;
        }

        local current_album_songs = album_song_lists[current_album_selection];
        if (current_album_songs.len() == 0) return false;

        if (signal == "up") {
            current_song_selection--;
            if (current_song_selection < 0) {
                current_song_selection = current_album_songs.len() - 1;
            }
            fe.nv.jukebox_last_song = current_song_selection;

            if (audiomode.m_index != null) {
                audiomode.m_index = current_song_selection;
                audiomode.change_track(0);
            }

            update_car_display();
            return true;
        } else if (signal == "down") {
            current_song_selection++;
            if (current_song_selection >= current_album_songs.len()) {
                current_song_selection = 0;
            }
            fe.nv.jukebox_last_song = current_song_selection;

            if (audiomode.m_index != null) {
                audiomode.m_index = current_song_selection;
                audiomode.change_track(0);
            }

            update_car_display();
            return true;
        }
    }

    if (signal == "up" || signal == "down" || signal == "left" || signal == "right" || signal == "select") {
        return false;
    }

    return false;
}

//==============================================
// TICK CALLBACK
//==============================================
local last_check = 0;

fe.add_ticks_callback("jukebox_tick");
function jukebox_tick(ttime) {
    // CONTINUOUS VOLUME CONTROL
    local downState = fe.get_input_state("custom2");
    local upState = fe.get_input_state("custom1");

    if (ttime - lastVolumeChangeTime >= volumeChangeInterval) {
        if (downState && fe.ambient_sound.volume > 0) {
            adjust_volume(-volumeStep);
            lastVolumeChangeTime = ttime;
        } else if (upState && fe.ambient_sound.volume < 100) {
            adjust_volume(volumeStep);
            lastVolumeChangeTime = ttime;
        }
    }

    // Auto-hide volume display
    if (show_volume_display && ttime - volume_display_time > volume_display_duration) {
        hide_volume();
    }

    // CALCULATE FFT SUM FIRST
    local fftSum = 1.0;
    for (local i = 0; i < fe.ambient_sound.fft_bands; i++) {
        fftSum += fe.ambient_sound.fft[i];
    }

    local avgFFT = fftSum / fe.ambient_sound.fft_bands.tofloat();

    if (cfg["Visualizers"] == "Yes") {
        // side_bars_blur visualization
        local side_bars = 10 + (avgFFT * 450).tointeger();
        if (side_bars > 255) side_bars = 255;
        if (side_bars < 150) side_bars = 0;
        side_bars_blur.alpha = side_bars;

        // side_bars_blur2 visualization
        local side_bars2_alpha = 10 + (avgFFT * 450).tointeger();
        if (side_bars2_alpha > 255) side_bars2_alpha = 255;
        if (side_bars2_alpha < 150) side_bars2_alpha = 0;
        side_bars_blur2.alpha = side_bars2_alpha;

        // MUSIC VISUALIZER UPDATE - DOT MATRIX
        for (local i = 0; i < fe.ambient_sound.fft_bands; i++) {
            // Calculate how many dots should be lit based on FFT value
            local barHeight = (fe.ambient_sound.fft[i] * dotsPerBar * 2.0).tointeger();
            if (barHeight > dotsPerBar) barHeight = dotsPerBar;

            // Light up dots from bottom to calculated height
            for (local d = 0; d < dotsPerBar; d++) {
                if (d < barHeight) {
                    bars_m[i][d].alpha = 255; // Lit
                } else {
                    bars_m[i][d].alpha = 0; // Dim
                }
            }
        }
    }
    
    // Auto-sync with audiomode (only if plugin available)
    if (plugin_available && ttime - last_check > 1000) {
        if (audiomode && audiomode.m_index != null) {
            local audiomode_index = audiomode.m_index;

            if (audiomode_index != current_song_selection && audiomode_index >= 0) {
                local current_album_songs = album_song_lists[current_album_selection];
                if (audiomode_index < current_album_songs.len()) {
                    current_song_selection = audiomode_index;
                    update_car_display();
                    fe.nv.jukebox_last_song = current_song_selection;
                }
            }
        }
        last_check = ttime;
    }
}

//  local buttons = fe.add_image("Stereo_Artwork/button_outer3.png",0,0,1920,1080);
//  buttons.zorder=500
