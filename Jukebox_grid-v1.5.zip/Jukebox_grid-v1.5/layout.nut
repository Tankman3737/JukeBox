/**
 * Jukebox_grid Layout
 *
 * @summary A short description.
 * @version 0.0.1 2026-1-9
 * @author Tankman3737
 * @url https://github.com/Tankman3737
 *
 * @requires
 * @module blur 0.1.0 https://github.com/Chadnaut/Attract-Mode-Modules
 * @module fade (Included with AM)
 * @module file (Included with AM)
 * @module inertia 3.00 https://github.com/oomek/attract-extra
 * @module mask 0.3.1 https://github.com/Chadnaut/Attract-Mode-Modules
 * @module scrollingtext 1.0
 * @module wheel 140.0 https://github.com/oomek/attract-extra
 */

class UserConfig {
    </ label="Theme layout", help="Select which theme to load", options="Wurlitzer,Car1,Car2,Classic car,Headspace,Classic", order=1 />
    theme_layout = "Wurlitzer";

    </ label="Car Stereo Color", help="Select color of the theme", options="Red,Green,Blue,Purple", order=2 />
    color = "Red";

    </ label="Wurlitzer & Car Visualizers", help="Visualizers On/Off", options="Yes,No", order=3 />
    Visualizers = "No";

    </ label="Reflection Alpha", help="Reflection Alpha", options="0,5,10,20,30,40,50", order=3 />
    Reflection = "50";

    </ label="---Everything Below---", help="---Choose visualizer style---", order=4 />
    Head_Space_Compact_Visualizer2 = "---Is for Headspace & Classic---";

    </ label="Head Space & Compact Visualizer", help="Choose visualizer style", options="Waves,Ripple,LED,Bars,Album_Art", order=5 />
    Head_Space_Compact_Visualizer = "Waves";

    </ label="Wave and Dot Vis colour", help="Select wave color", options="RED,BLUE,CYAN,GREEN,PURPLE", order=6 />
    Wave_colour = "RED";

    </ label="Waves with LED", help="Enable LED shader behind Waves", options="Yes,No", order=7 />
    led_overlay = "No";
}

cfg <- fe.get_config();

fe.layout.preserve_aspect_ratio = true;
fe.layout.width = 1920;
fe.layout.height = 1080;

// MARK:creates the music romlist file

// Load only the selected layout]

switch (cfg["theme_layout"]) {
    case "Wurlitzer":
        fe.do_nut("Wurlitzer.nut");
        break;

    case "Car1":
        fe.do_nut("Car.nut");
        break;
    case "Car2":
        fe.do_nut("Car2.nut");
        break;
        case "Classic car":
        fe.do_nut("Classic_car.nut");
        break;

    case "Headspace":
        fe.do_nut("Headspace.nut");
        break;
    case "Classic":
        fe.do_nut("Classic.nut");
        break;
}
