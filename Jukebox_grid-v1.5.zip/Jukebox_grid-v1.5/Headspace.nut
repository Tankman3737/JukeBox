/**
 * Jukebox_grid - Headspace
 *
 * @summary A short description.
 * @version 0.0.1 2026-1-9
 * @author Tankman3737
 * @url https://github.com/Tankman3737
 *
 * @requires
 * @module blur 0.1.0 https://github.com/Chadnaut/Attract-Mode-Modules
 * @module inertia 3.00 https://github.com/oomek/attract-extra
 * @module mask 0.3.1 https://github.com/Chadnaut/Attract-Mode-Modules
 * @module scrollingtext 1.0
 * @module wheel 140.0 https://github.com/oomek/attract-extra
 */

fe.layout.width = 1920;
fe.layout.height = 1080;

local flw = fe.layout.width;
local flh = fe.layout.height;
fe.layout.font = "verdana.ttf";

local surfW = 700;
local surfH = 1020;
local surfX = 0;
local surfY = 0;

fe.load_module("inertia");
fe.load_module("mask");
fe.load_module("blur");
fe.load_module("wheel");
fe.load_module("scrollingtext");

local theme_colours = {
    RED = [ [ 250, 0, 0 ] ],
    GREEN = [ [ 8, 255, 7 ] ],
    BLUE = [ [ 0, 0, 200 ] ],
    CYAN = [ [ 0, 90, 200 ] ],
    PURPLE = [ [ 74, 0, 134 ] ]
};

local selected = cfg["Wave_colour"];
local cols = theme_colours[selected];

//==============================================
// MODE CONTROL & PLUGIN - SAFE INITIALIZATION
//==============================================
local active_mode = 1; // Start with tracks active

// SAFE PLUGIN CHECK
local audiomode = null;
local plugin_available = false;

try {
    if ("AudioMode_xtra" in fe.plugin) {
        audiomode = fe.plugin["AudioMode_xtra"];
        plugin_available = true;
        fe.log("INFO: AudioMode_xtra plugin loaded successfully");
    } else {
        fe.log("WARNING: AudioMode_xtra plugin not found, running in limited mode");
    }
} catch (e) {
    fe.log("ERROR: Failed to check for AudioMode_xtra plugin: " + e);
    plugin_available = false;
}

//==============================================
// ALBUM TO FOLDER MAPPING - AUTO-DETECT
//==============================================
local total_albums = 0;
if (plugin_available && audiomode && audiomode.m_folders) {
    total_albums = audiomode.m_folders.len();
} else {
    fe.log("INFO: Running without AudioMode_xtra plugin, albums disabled");
}

local album_to_folder_map = {};
for (local i = 0; i < total_albums; i++) {
    album_to_folder_map[i] <- i;
}

local current_album_selection = 0;
local current_song_selection = 0;

//==============================================
// FOLDER STATE PERSISTENCE
//==============================================
if (!("jukebox_last_folder" in fe.nv)) {
    fe.nv.jukebox_last_folder <- 0;
}

if (!("jukebox_last_album" in fe.nv)) {
    fe.nv.jukebox_last_album <- 0;
}

if (!("jukebox_last_song" in fe.nv)) {
    fe.nv.jukebox_last_song <- 0;
}

//==============================================
// SONG LISTS - LOAD DATA
//==============================================
local album_song_lists = [];
local album_display_names = [];

function load_all_song_lists() {
    album_song_lists = [];
    album_display_names = [];

    if (!plugin_available || !audiomode) {
        fe.log("INFO: AudioMode_xtra not available, no songs loaded");
        // Add dummy data to prevent crashes
        album_song_lists.push([]);
        album_display_names.push(["AudioMode_xtra Plugin"]);
        total_albums = 1;
        return;
    }

    for (local album_idx = 0; album_idx < total_albums; album_idx++) {
        local folder_idx = album_to_folder_map[album_idx];

        if (folder_idx < audiomode.m_folders.len()) {
            local folder_path = audiomode.m_folders[folder_idx];
            local dir = DirectoryListing(folder_path);

            local song_files = [];
            local display_names = [];

            foreach (filename in dir.results) {
                local lower_filename = filename.tolower();
                if (lower_filename.find(".jpg") != null || lower_filename.find(".jpeg") != null || lower_filename.find(".png") != null || lower_filename.find(".gif") != null || lower_filename.find(".bmp") != null) {
                    continue;
                }

                song_files.push(filename);

                local display_name = filename;
                local parts = split(filename, "/\\");
                if (parts.len() > 0) {
                    display_name = parts[parts.len() - 1];
                    local dot_pos = display_name.find(".", display_name.len() - 5);
                    if (dot_pos != null) {
                        display_name = display_name.slice(0, dot_pos);
                    }
                }
                display_names.push(display_name);
            }

            album_song_lists.push(song_files);
            album_display_names.push(display_names);
            fe.log("Album " + album_idx + ": Loaded " + song_files.len() + " songs");
        } else {
            album_song_lists.push([]);
            album_display_names.push([]);
        }
    }
}

local BG = fe.add_image("headspace_artwork/win.png", 0, 0, 1920, 1080);
local vin = fe.add_image("headspace_artwork/vin.png", 0, 0, 1920, 1080);
vin.alpha = 128;

local slide = fe.add_surface(1920, 1080);
slide.x = 0;
slide.y = 0;

local Psurf = fe.add_surface(1920, 1080);
Psurf.x = 0;
Psurf.y = 0;

local logoslide = fe.add_surface(1920, 1080);
logoslide.x = 0;
logoslide.y = 0;

//MARK:CONES
local conet = Psurf.add_image("headspace_artwork/lefttop.png", 105, 352, 96, 98);
conet.anchor = Anchor.Centre;
local conem = Psurf.add_image("headspace_artwork/leftmiddle.png", 150, 490, 96, 98);
conem.anchor = Anchor.Centre;
local coneb = Psurf.add_image("headspace_artwork/leftmiddle.png", 145, 610, 90, 90);
coneb.anchor = Anchor.Centre;

local conetr = slide.add_image("headspace_artwork/righttop.png", 1810, 352, 101, 111);
conetr.anchor = Anchor.Centre;
local conemr = slide.add_image("headspace_artwork/rightmiddle.png", 1765, 490, 96, 98);
conemr.anchor = Anchor.Centre;
local conebr = slide.add_image("headspace_artwork/rightmiddle.png", 1770, 610, 90, 90);
conebr.anchor = Anchor.Centre;

// --- Helper to average bands over a range ---
function avg_fft(lo, hi) {
    local sum = 0.0;
    local count = 0;
    for (local i = lo; i <= hi && i < fe.ambient_sound.fft_bands; i++) {
        sum += fe.ambient_sound.fft[i];
        count++;
    }
    return count > 0 ? sum / count : 0.0;
}

// --- Animate cones ---
fe.add_ticks_callback("on_tick5");
function on_tick5(ttime) {
    local bass = avg_fft(0, 2);
    local mid = avg_fft(3, 10);
    local treb = avg_fft(11, fe.ambient_sound.fft_bands - 1);

    coneb.width = 90 + bass * 20;
    coneb.height = 90 + bass * 20;

    conem.width = 96 + mid * 20;
    conem.height = 98 + mid * 20;

    conet.width = 101 + treb * 30;
    conet.height = 109 + treb * 30;

    conebr.width = 90 + bass * 20;
    conebr.height = 90 + bass * 20;

    conemr.width = 96 + mid * 20;
    conemr.height = 98 + mid * 20;

    conetr.width = 101 + treb * 30;
    conetr.height = 109 + treb * 30;
}

local greenleft = Psurf.add_image("headspace_artwork/L_green.png", 10, 0, 1920, 1080);

//==============================================
// ALBUM LIST (LEFT SIDE)
//==============================================
local albumsurf = Psurf.add_surface(500, 500);
albumsurf.x = 220;
albumsurf.y = 280;

local album_highlight = albumsurf.add_rectangle(15, 160, 450, 35);
album_highlight.set_rgb(0, 255, 0);
album_highlight.alpha = 50;

// Create 9 album text entries (-4 to +4 offset)
local album_texts = [];
for (local i = -4; i <= 4; i++) {
    local yPos = 160 + i * 40;
    local txt = albumsurf.add_text("", 0, yPos, 800, 35);
    txt.align = Align.Left;

    if (i == 0) {
        txt.set_rgb(0, 255, 0); // Highlight current
    }

    album_texts.append({ offset = i, text = txt });
}

function update_album_list() {
    foreach (entry in album_texts) {
        local idx = current_album_selection + entry.offset;

        if (plugin_available && audiomode && idx >= 0 && idx < total_albums) {
            local album_name = audiomode.get_folder_name(idx);
            entry.text.msg = album_name;
        } else {
            entry.text.msg = idx == current_album_selection ? "Please enable" : "";
        }
    }
}

local greenleft2 = Psurf.add_image("headspace_artwork/L_ear.png", 0, 0, 1920, 1080);

local greenright = slide.add_image("headspace_artwork/green right.png", 0, 0, 1920, 1080);

//==============================================
// TRACK LIST (RIGHT SIDE - where visualizer was)
//==============================================
local tracksurf = slide.add_surface(460, 365);
tracksurf.x = 1270;
tracksurf.y = 275;

// Create track list display
local track_texts = [];
local visible_tracks = 9;

for (local i = 0; i < visible_tracks; i++) {
    local txt = tracksurf.add_text("", 0, i * 40, 450, 35);
    txt.align = Align.Left;
    txt.charsize = 16;
    track_texts.append(txt);
}

function update_track_list() {
    if (current_album_selection >= album_song_lists.len()) return;

    local songs = album_display_names[current_album_selection];
    local scroll_offset = 0;

    // Calculate scroll to keep current song visible
    if (current_song_selection >= visible_tracks / 2) {
        scroll_offset = current_song_selection - visible_tracks / 2;
        if (scroll_offset + visible_tracks > songs.len()) {
            scroll_offset = songs.len() - visible_tracks;
            if (scroll_offset < 0) scroll_offset = 0;
        }
    }

    for (local i = 0; i < visible_tracks; i++) {
        local song_idx = i + scroll_offset;

        if (song_idx < songs.len()) {
            track_texts[i].msg = songs[song_idx];

            // Highlight current track
            if (song_idx == current_song_selection) {
                track_texts[i].set_rgb(0, 255, 0);
            } else {
                track_texts[i].set_rgb(255, 255, 255);
            }
        } else {
            track_texts[i].msg = "";
        }
    }
}

local mask = ::fe.add_image("headmask.png");
mask.visible = false;
local tests = Mask(Psurf.add_surface(685, 190, 550, 410));
tests.mask = mask;



//MARK: BARS (DOT MATRIX)
if (cfg["Head_Space_Compact_Visualizer"] == "Bars") {
    local bars_surface = tests.add_surface(345, 260, 695, 520);
    bars_surface.anchor = Anchor.Centre;

    local headblack = bars_surface.add_image("headspace_artwork/Head_black3.png", 0, 0, 560, 410);
    headblack.set_rgb(0, 0, 0);
    headblack.zorder = 0;

    // Add album art behind bars
    local bars_album_art = bars_surface.add_image("", 347, 260, 695, 520);
    bars_album_art.anchor = Anchor.Centre;
    bars_album_art.alpha = 50; // Slightly transparent so bars show better

    fe.ambient_sound.fft_bands = 30;

    local numBands = fe.ambient_sound.fft_bands;
    local dotsPerBar = 15;
    local dotSize = 18;
    local dotSpacing = 2;
    local barWidth = 695.0 / numBands;

    local bars_m = [];

    // Create dot matrix bars
    for (local i = 0; i < numBands; i++) {
        local barDots = [];
        local xPos = i * barWidth + barWidth / 2 - dotSize / 2;

        for (local d = 0; d < dotsPerBar; d++) {
            local yPos = 520 - d * (dotSize + dotSpacing);

            local dot = bars_surface.add_rectangle(xPos, yPos, dotSize, dotSize);
            dot.set_rgb(cols[0][0], cols[0][1], cols[0][2]); // Use theme color
            dot.alpha = 50; // Dim by default
            dot.corner_ratio = 0.2;

            barDots.append(dot);
        }
        bars_m.push(barDots);
    }

    // Animate dots
    fe.add_ticks_callback("update_bars_dots");
    function update_bars_dots(ttime) {
        for (local i = 0; i < numBands; i++) {
            local barHeight = (fe.ambient_sound.fft[i] * dotsPerBar * 2.0).tointeger();
            if (barHeight > dotsPerBar) barHeight = dotsPerBar;

            for (local d = 0; d < dotsPerBar; d++) {
                if (d < barHeight) {
                    bars_m[i][d].alpha = 255; // Lit
                } else {
                    bars_m[i][d].alpha = 0; // Dim
                }
            }
        }
    }

    // Update album art function for bars
    function update_bars_album_art() {
        if (plugin_available && audiomode && current_album_selection < audiomode.m_folders.len()) {
            local cover_jpg = audiomode.m_folders[current_album_selection] + "/cover.jpg";
            local cover_png = audiomode.m_folders[current_album_selection] + "/cover.png";

            bars_album_art.file_name = cover_jpg;
            if (bars_album_art.texture_width == 0) {
                bars_album_art.file_name = cover_png;
            }
        } else {
            bars_album_art.file_name = "";
        }
    }
}
//MARK: ALBUM ART
local album_art = null;
if (cfg["Head_Space_Compact_Visualizer"] == "Album_Art") {
    album_art = tests.add_image("", 345, 260, 695, 520);
    album_art.anchor = Anchor.Centre;
}

function update_album_art() {
    if (album_art && plugin_available && audiomode && current_album_selection < audiomode.m_folders.len()) {
        local cover_jpg = audiomode.m_folders[current_album_selection] + "/cover.jpg";
        local cover_png = audiomode.m_folders[current_album_selection] + "/cover.png";

        album_art.file_name = cover_jpg;
        if (album_art.texture_width == 0) {
            album_art.file_name = cover_png;
        }
    } else if (album_art) {
        album_art.file_name = "";
    }
}

// MARK: WAVES
if (cfg["Head_Space_Compact_Visualizer"] == "Waves") {
    local bg = tests.add_rectangle(surfX, surfY, surfW, surfH);
    bg.zorder = -100;

    switch (cfg["Wave_colour"]) {
        case "GREEN":
            bg.set_rgb(1, 100, 21);
            break;
        case "RED":
            bg.set_rgb(134, 0, 0);
            break;
        case "BLUE":
            bg.set_rgb(0, 8, 98);
            break;
        case "CYAN":
            bg.set_rgb(91, 109, 126);
            break;
        case "PURPLE":
            bg.set_rgb(134, 0, 69);
            break;
    }

    // Waves surface
    local background = tests.add_surface(surfW, surfH);
    background.blend_mode = BlendMode.Overlay;
    background.x = surfX;
    background.y = surfY;
    background.zorder = -90;

    // Shader setup for Waves
    local bgshader = fe.add_shader(Shader.Fragment, "headspace_artwork/playhead.frag");
    bgshader.set_param("resolution", background.width.tofloat(), background.height.tofloat());
    bgshader.set_param("surfacePos", surfX.tofloat(), surfY.tofloat());
    background.shader = bgshader;

    // Animation vars
    local audioSmooth = 0.0;
    local shaderTime = 0.0;
    local vScale = 0.2;

    fe.add_ticks_callback("updateShader");
    function updateShader(ttime) {
        shaderTime = fe.layout.time;
        local val = fe.ambient_sound.fft.len() > 5 ? fe.ambient_sound.fft[5] : 0.0;
        audioSmooth = audioSmooth * 0.9 + val * 0.2;

        bgshader.set_param("resolution", background.width.tofloat(), background.height.tofloat());
        bgshader.set_param("surfacePos", background.x.tofloat(), background.y.tofloat());
        bgshader.set_param("ttime", shaderTime);
        bgshader.set_param("iAudio", audioSmooth);
        bgshader.set_param("vScale", vScale);
        bgshader.set_param("centerPoint", 0.5, 0.1);
    }

    // --- LED Overlay option ---
    if (cfg["led_overlay"] == "Yes") {
        local LED = tests.add_surface(275, 210, 550, 420);
        LED.anchor = Anchor.Centre;
        LED.zorder = -95;

        LED.set_rgb(175, 170, 170);
        LED.shader = ::fe.add_shader(Shader.Fragment, "bump.frag");
        LED.shader.set_param("depth", 1.5);
        LED.shader.set_param("light1_rgba", 1.0, 0.0, 0.0, 1.0);
        LED.shader.set_param("light2_rgba", 0.0, 1.0, 0.0, 1.0);
        LED.shader.set_param("light3_rgba", 0.0, 0.0, 1.0, 1.0);
        LED.shader.set_param("light4_rgba", 1.0, 1.0, 0.0, 1.0);
        LED.shader.set_param("light5_rgba", 1.0, 0.0, 1.0, 1.0);
        LED.shader.set_param("light6_rgba", 0.0, 1.0, 1.0, 1.0);

        fe.add_transition_callback("on_transition");
        function on_transition(ttype, var, ttime) {
            switch (ttype) {
                case Transition.ToNewList:
                case Transition.FromOldSelection:
                    LED.shader.set_param("texture_size", LED.texture_width, LED.texture_height);
                    break;
            }
        }

        fe.add_ticks_callback("on_tickspeak");
        function on_tickspeak(ttime) {
            local treb = avg_fft(11, fe.ambient_sound.fft_bands - 1);
            local t = fe.layout.time / 1000;

            local x = 0.5 + 0.5 * cos(t + treb * 5);
            local y = 0.5 + 0.5 * sin(t + treb * 5);
            LED.shader.set_param("light1_pos", x, y, 0.8);

            x = 0.5 + 0.5 * cos(t + 1.046 + treb * 5);
            y = 0.5 + 0.5 * sin(t + 1.046 + treb * 5);
            LED.shader.set_param("light2_pos", x, y, 0.8);

            x = 0.5 + 0.5 * cos(t + 2.092 + treb * 5);
            y = 0.5 + 0.5 * sin(t + 2.092 + treb * 5);
            LED.shader.set_param("light3_pos", x, y, 0.8);

            x = 0.5 + 0.5 * cos(t + 3.14 + treb * 5);
            y = 0.5 + 0.5 * sin(t + 3.14 + treb * 5);
            LED.shader.set_param("light4_pos", x, y, 0.8);

            x = 0.5 + 0.5 * cos(t + 4.184 + treb * 5);
            y = 0.5 + 0.5 * sin(t + 4.184 + treb * 5);
            LED.shader.set_param("light5_pos", x, y, 0.8);

            x = 0.5 + 0.5 * cos(t + 5.23 + treb * 5);
            y = 0.5 + 0.5 * sin(t + 5.23 + treb * 5);
            LED.shader.set_param("light6_pos", x, y, 0.8);
        }
    }
}

if (cfg["Head_Space_Compact_Visualizer"] == "Ripple") {
    local headblack = Psurf.add_image("headspace_artwork/Head_black2.png", 0, 0, 1920, 1080);
    headblack.set_rgb(12, 88, 3);

    local ripsurf = Psurf.add_surface(960, 400, 550, 420);
    ripsurf.anchor = Anchor.Centre;

    local rippleSurf = ripsurf.add_surface(275, 210, 700, 700);
    rippleSurf.anchor = Anchor.Centre;
    rippleSurf.zorder = 100;

    // Add album art behind ripple
    local ripple_album_art = rippleSurf.add_image("", 350, 350, 550, 420);
    ripple_album_art.anchor = Anchor.Centre;
    ripple_album_art.alpha = 200; // Slightly transparent
    ripple_album_art.zorder = 50; // Behind ripple effect

    local mask = fe.add_image("headspace_artwork/headmask.png");
    mask.visible = false;
    ripsurf.shader = fe.add_shader(Shader.Fragment, "mask.frag");
    ripsurf.shader.set_texture_param("mask", mask);

    local rippleShader = fe.add_shader(Shader.Fragment, "ripple.frag");
    rippleShader.set_param("resolution", surfW.tofloat(), surfH.tofloat());
    rippleSurf.shader = rippleShader;

    local audioSmooth = 0.0;
    local shaderTime = 0.0;
    local vScale = 0.1;
    local useAudio = 1;
    rippleShader.set_param("useAudio", useAudio);

    fe.add_ticks_callback("updateRippleShader");
    function updateRippleShader(tt) {
        shaderTime += tt * 0.001;
        local val = 0.0;
        if (fe.ambient_sound.fft.len() > 5) val = fe.ambient_sound.fft[5];
        audioSmooth = audioSmooth * 0.2 + val * 0.1;

        rippleShader.set_param("ttime", shaderTime);
        rippleShader.set_param("iAudio", audioSmooth);
        rippleShader.set_param("vScale", vScale);
    }

    // Update album art function for ripple
    function update_ripple_album_art() {
        if (plugin_available && audiomode && current_album_selection < audiomode.m_folders.len()) {
            local cover_jpg = audiomode.m_folders[current_album_selection] + "/cover.jpg";
            local cover_png = audiomode.m_folders[current_album_selection] + "/cover.png";

            ripple_album_art.file_name = cover_jpg;
            if (ripple_album_art.texture_width == 0) {
                ripple_album_art.file_name = cover_png;
            }
        } else {
            ripple_album_art.file_name = "";
        }
    }
}

//MARK: LED
if (cfg["Head_Space_Compact_Visualizer"] == "LED") {
    local headblack = tests.add_image("headspace_artwork/Head_black3.png", 0, 0, 550, 406);
    headblack.set_rgb(0, 0, 0);

    local LED = tests.add_surface(275, 210, 550, 420);
    LED.anchor = Anchor.Centre;
    LED.set_rgb(175, 170, 170);
    LED.shader = ::fe.add_shader(Shader.Fragment, "bump.frag");
    LED.shader.set_param("depth", 1.5);
    LED.shader.set_param("light1_rgba", 1.0, 0.0, 0.0, 1.0);
    LED.shader.set_param("light2_rgba", 0.0, 1.0, 0.0, 1.0);
    LED.shader.set_param("light3_rgba", 0.0, 0.0, 1.0, 1.0);
    LED.shader.set_param("light4_rgba", 1.0, 1.0, 0.0, 1.0);
    LED.shader.set_param("light5_rgba", 1.0, 0.0, 1.0, 1.0);
    LED.shader.set_param("light6_rgba", 0.0, 1.0, 1.0, 1.0);

    ::fe.add_transition_callback("on_transition_led");
    function on_transition_led(ttype, var, ttime) {
        switch (ttype) {
            case Transition.ToNewList:
            case Transition.FromOldSelection:
                LED.shader.set_param("texture_size", LED.texture_width, LED.texture_height);
                break;
        }
        return false;
    }

    ::fe.add_ticks_callback("on_tickspeak_led");
    function on_tickspeak_led(ttime) {
        local treb = avg_fft(11, fe.ambient_sound.fft_bands - 1);
        local t = fe.layout.time / 1000;

        local x = 0.5 + 0.5 * cos(t + treb * 5);
        local y = 0.5 + 0.5 * sin(t + treb * 5);
        LED.shader.set_param("light1_pos", x, y, 0.8);

        x = 0.5 + 0.5 * cos(t + 1.046 + treb * 5);
        y = 0.5 + 0.5 * sin(t + 1.046 + treb * 5);
        LED.shader.set_param("light2_pos", x, y, 0.8);

        x = 0.5 + 0.5 * cos(t + 2.092 + treb * 5);
        y = 0.5 + 0.5 * sin(t + 2.092 + treb * 5);
        LED.shader.set_param("light3_pos", x, y, 0.8);

        x = 0.5 + 0.5 * cos(t + 3.14 + treb * 5);
        y = 0.5 + 0.5 * sin(t + 3.14 + treb * 5);
        LED.shader.set_param("light4_pos", x, y, 0.8);

        x = 0.5 + 0.5 * cos(t + 4.184 + treb * 5);
        y = 0.5 + 0.5 * sin(t + 4.184 + treb * 5);
        LED.shader.set_param("light5_pos", x, y, 0.8);

        x = 0.5 + 0.5 * cos(t + 5.23 + treb * 5);
        y = 0.5 + 0.5 * sin(t + 5.23 + treb * 5);
        LED.shader.set_param("light6_pos", x, y, 0.8);
    }
}

//MARK: ALBUM ART VISUALIZER
//MARK: ALBUM ART VISUALIZER
local album_art = null;
if (cfg["Head_Space_Compact_Visualizer"] == "Album_Art") {
    album_art = tests.add_image("", 275, 210, 550, 410);
    album_art.anchor = Anchor.Centre;
}

function update_album_art() {
    if (album_art && plugin_available && audiomode && current_album_selection < audiomode.m_folders.len()) {
        local cover_jpg = audiomode.m_folders[current_album_selection] + "/cover.jpg";
        local cover_png = audiomode.m_folders[current_album_selection] + "/cover.png";

        album_art.file_name = cover_jpg;
        if (album_art.texture_width == 0) {
            album_art.file_name = cover_png;
        }
    } else if (album_art) {
        album_art.file_name = "";
    }
}
local greenright = slide.add_image("headspace_artwork/R_ear.png", 0, 0, 1920, 1080);

local snap = Psurf.add_artwork("snap", 675, 195, 565, 420);
local mask2 = fe.add_image("headspace_artwork/snapmask.png");
mask2.visible = false;
snap.shader = ::fe.add_shader(Shader.Fragment, "mask.frag");
snap.shader.set_texture_param("mask", mask2);

//MARK:head
local logobar = logoslide.add_image("headspace_artwork/logo_bar.png", 0, 0, 1920, 1080);

local CGamesurf = logoslide.add_surface(390, 40);
CGamesurf.x = 765;
CGamesurf.y = 195;

local CSong = CGamesurf.add_text("", 0, 5, 960, 30);
CSong.align = Align.Left;
CSong.outline = 1;
CSong.set_outline_rgb(0, 0, 0);

local HS = logoslide.add_image("headspace_artwork/headshadow.png", 0, 0, 1920, 1080);
HS.alpha = 128;
local player = fe.add_image("headspace_artwork/head2.png", 0, 0, 1920, 1080);

local PS = fe.add_image("headspace_artwork/playslider.png", 740, 620, 45, 22);

CSong = Inertia(CSong, 25500, "x");
logoslide = Inertia(logoslide, 1500, "y");
slide = Inertia(slide, 1500, "x");
PS = Inertia(PS, "x");

function update_display() {
    // Update album/track lists
    update_album_list();
    update_track_list();

    // Update scrolling song name
    if (current_album_selection < album_display_names.len() && current_song_selection < album_display_names[current_album_selection].len()) {
        CSong.msg = album_display_names[current_album_selection][current_song_selection];
    }
    if (cfg["Head_Space_Compact_Visualizer"] == "Album_Art") {
        update_album_art();
    }

    if (cfg["Head_Space_Compact_Visualizer"] == "Bars") {
        update_bars_album_art();
    }
    if (cfg["Head_Space_Compact_Visualizer"] == "Ripple") {
        update_ripple_album_art();
    }
}

// Track progress bar animation
local last_track_file = "";

fe.add_ticks_callback("update_progress_bar");
function update_progress_bar(ttime) {
    local current_file = fe.ambient_sound.file_name;

    // Check if track changed
    if (current_file != last_track_file && current_file.len() > 0) {
        last_track_file = current_file;

        // Reset progress bar animation
        PS.x = 740;
        PS.to_x = 1135;
        PS.tween_x = Tween.Linear;
        PS.time_x = fe.ambient_sound.duration; // Duration in milliseconds

        fe.log("Progress bar reset for new track, duration: " + fe.ambient_sound.duration + "ms");
    }
}

function slide_animation(ttype, var, ttime) {
    if (ttype == Transition.EndNavigation || ttype == Transition.StartLayout || ttype == Transition.ToNewList) {
        // update_display();
        // PS.tween_x = Tween.Linear;
        // PS.x = 740;
        // PS.to_x = 1135;
        // PS.time_x = fe.ambient_sound.duration

        CSong.loop_x = true;
        CSong.tween_x = Tween.Linear;
        CSong.delay_x = 1500;
        CSong.x = 500;
        CSong.to_x = -700;

        update_display();
    }
}

fe.add_transition_callback("slide_animation");

local playtext2 = fe.add_text("", 885, 656, 200, 20);
local playtext3 = fe.add_text("", 885, 656, 100, 20);

fe.add_ticks_callback("on_tick_time");
function on_tick_time(ttime) {
    // Total duration
    local currentTime = fe.ambient_sound.duration / 1000.0; // Convert to seconds
    local minutes = currentTime / 60;
    local seconds = currentTime % 60;
    playtext2.msg = format(" %d:%02d ", minutes, seconds);

    // Current time
    local currentTime2 = fe.ambient_sound.time / 1000.0; // Convert to seconds
    local minutes2 = currentTime2 / 60;
    local seconds2 = currentTime2 % 60;
    playtext3.msg = format(" %d:%02d ", minutes2, seconds2) + "/";
}

// --- Volume Meter Bars Setup ---
local numBars = 10;
local barWidth = 20;
local barHeight = 40;
local spacing = 5;
local baseX = 838;
local baseY = 132;

local volumeBars = [];

for (local i = 0; i < numBars; i++) {
    local rect = fe.add_rectangle(baseX + i * (barWidth + spacing), baseY, barWidth, barHeight);
    rect.set_rgb(11, 92, 4);
    rect.alpha = 80;
    rect.visible = true;
    volumeBars.append(rect);
}

function updateVolumeBars() {
    local vol = "ambient_volume" in fe.nv ? fe.nv.ambient_volume : 50;
    local activeBars = floor(vol / (100.0 / numBars));

    for (local i = 0; i < numBars; i++) {
        if (i < activeBars) {
            volumeBars[i].alpha = 255;
        } else {
            volumeBars[i].alpha = 80;
        }
    }
}

function load_initial_volume() {
    local vol = "ambient_volume" in fe.nv ? fe.nv.ambient_volume : 50;
    fe.ambient_sound.volume = vol;
    updateVolumeBars();
}

function adjust_volume(amount) {
    local v = fe.ambient_sound.volume + amount;
    if (v < 0) v = 0;
    if (v > 100) v = 100;

    fe.ambient_sound.volume = v;
    fe.nv.ambient_volume = v;
    updateVolumeBars();
}

local volumeStep = 5;
local volumeChangeInterval = 200;
local lastVolumeChangeTime = 0;

function continuousVolumeControl(ttime) {
    local downState = fe.get_input_state("custom2");
    local upState = fe.get_input_state("custom1");

    if (ttime - lastVolumeChangeTime >= volumeChangeInterval) {
        if (downState && fe.ambient_sound.volume > 0) {
            adjust_volume(-volumeStep);
            lastVolumeChangeTime = ttime;
        } else if (upState && fe.ambient_sound.volume < 100) {
            adjust_volume(volumeStep);
            lastVolumeChangeTime = ttime;
        }
    }
}
fe.add_ticks_callback("continuousVolumeControl");

//==============================================
// INITIALIZE
//==============================================
load_all_song_lists();

current_album_selection = fe.nv.jukebox_last_album;
if (current_album_selection >= total_albums && total_albums > 0) {
    current_album_selection = 0;
} else if (total_albums == 0) {
    current_album_selection = 0;
}

current_song_selection = fe.nv.jukebox_last_song;

if (plugin_available && audiomode && current_album_selection in album_to_folder_map) {
    local folder_index = album_to_folder_map[current_album_selection];
    if (folder_index >= 0 && folder_index != audiomode.get_current_folder()) {
        audiomode.switch_to_folder(folder_index);
        fe.nv.jukebox_last_folder = folder_index;
    }
}

update_display();
load_initial_volume();

fe.log("Headspace layout loaded successfully - Plugin available: " + plugin_available);

//==============================================
// SIGNAL HANDLER
//==============================================
fe.add_signal_handler("headspace_signal");

local left_overlay = fe.add_image("headspace_artwork/black.png", 230, 280, 416, 357);
left_overlay.alpha = 128;

local right_overlay = fe.add_image("headspace_artwork/black.png", 1272, 280, 416, 357);
right_overlay.alpha = 0;

function headspace_signal(signal) {
    // CRITICAL: Never block exit or layout change signals
    if (signal == "exit_to_menu" || signal == "exit_game" || 
        signal == "prev_layout" || signal == "next_layout") {
        return false;
    }

    if (!plugin_available) {
        // When plugin not available, handle basic signals
        if (signal == "custom4") {
            active_mode = (active_mode == 1) ? 0 : 1;
            if (active_mode == 0) {
                left_overlay.alpha = 0;
                right_overlay.alpha = 128;
            } else {
                left_overlay.alpha = 128;
                right_overlay.alpha = 0;
            }
            return true;
        }
        // Block navigation but NOT exit signals
        if (signal == "left" || signal == "right" || signal == "up" || signal == "down" || signal == "select") {
            return true;
        }
        return false;
    }

    if (signal == "custom4" && active_mode == 1) {
        active_mode = 0;
        left_overlay.alpha = 0;
        right_overlay.alpha = 128;
        update_display();
        return true;
    }

    if (active_mode == 0) {
        // ALBUM MODE
        if (signal == "select") {
            if (!plugin_available || !audiomode) {
                fe.log("ERROR: Cannot select album - AudioMode_xtra not available");
                return true;
            }

            local folder_index = -1;
            if (current_album_selection in album_to_folder_map) {
                folder_index = album_to_folder_map[current_album_selection];
            }

            if (folder_index >= 0) {
                if (folder_index != audiomode.get_current_folder()) {
                    audiomode.switch_to_folder(folder_index);
                    fe.nv.jukebox_last_folder = folder_index;
                }

                current_song_selection = 0;
                if (album_song_lists[current_album_selection].len() > 0) {
                    audiomode.m_index = 0;
                    audiomode.change_track(0);
                }

                active_mode = 1;
                left_overlay.alpha = 128;
                right_overlay.alpha = 0;
                fe.nv.jukebox_last_song = 0;
                update_display();
            }
            return true;
        } else if (signal == "up") {
            if (total_albums == 0) return true;

            current_album_selection--;
            if (current_album_selection < 0) {
                current_album_selection = total_albums - 1;
            }
            fe.nv.jukebox_last_album = current_album_selection;
            update_display();
            return true;
        } else if (signal == "down") {
            if (total_albums == 0) return true;

            current_album_selection++;
            if (current_album_selection >= total_albums) {
                current_album_selection = 0;
            }
            fe.nv.jukebox_last_album = current_album_selection;
            update_display();
            return true;
        }
    } else {
        // SONG MODE
        if (!plugin_available || !audiomode) {
            return true;
        }

        local current_album_songs = album_song_lists[current_album_selection];
        if (current_album_songs.len() == 0) return false;

        if (signal == "up") {
            current_song_selection--;
            if (current_song_selection < 0) {
                current_song_selection = current_album_songs.len() - 1;
            }
            fe.nv.jukebox_last_song = current_song_selection;

            if (audiomode.m_index != null) {
                audiomode.m_index = current_song_selection;
                audiomode.change_track(0);
            }

            update_display();
            return true;
        } else if (signal == "down") {
            current_song_selection++;
            if (current_song_selection >= current_album_songs.len()) {
                current_song_selection = 0;
            }
            fe.nv.jukebox_last_song = current_song_selection;

            if (audiomode.m_index != null) {
                audiomode.m_index = current_song_selection;
                audiomode.change_track(0);
            }

            update_display();
            return true;
        }
    }

    if (signal == "up" || signal == "down" || signal == "left" || signal == "right" || signal == "select") {
        return false;
    }

    return false;
}

//==============================================
// TICK CALLBACK - AUTO-SYNC
//==============================================
local last_check = 0;

fe.add_ticks_callback("auto_sync");
function auto_sync(ttime) {
    // Auto-sync with audiomode (only if plugin available)
    if (plugin_available && ttime - last_check > 1000) {
        if (audiomode && audiomode.m_index != null) {
            local audiomode_index = audiomode.m_index;

            if (audiomode_index != current_song_selection && audiomode_index >= 0) {
                local current_album_songs = album_song_lists[current_album_selection];
                if (audiomode_index < current_album_songs.len()) {
                    current_song_selection = audiomode_index;
                    update_display();
                    fe.nv.jukebox_last_song = current_song_selection;
                }
            }
        }
        last_check = ttime;
    }
}
local words = fe.add_image("headspace_artwork/words.png");

local vissurf = fe.add_surface(980, 680, 1080, 500);
local VW = 1080;
local VH = 1;
vissurf.anchor = Anchor.Centre;
vissurf.zorder = 10;

fe.ambient_sound.fft_bands = 68;

local w = VW.tofloat() / fe.ambient_sound.fft_bands;

local bars_m = [];

// Colour blocks (add/remove as you like)
local colors = [
    [ 255, 0, 0 ], // red
    [ 0, 0, 255 ], // blue
    [ 255, 255, 0 ], // yellow
    [ 255, 0, 255 ]  // magenta
];

for (local i = 0; i < fe.ambient_sound.fft_bands; i++) {
    // Pick colour based on block
    local chunk = fe.ambient_sound.fft_bands.tofloat() / colors.len().tofloat();
    local idx = (i / chunk).tointeger();
    if (idx >= colors.len()) idx = colors.len() - 1; // clamp to last colour
    local c = colors[idx];
    local r = c[0],
        g = c[1],
        b = c[2];

    // Mixed channel (middle)
    local rectM = vissurf.add_rectangle(i * w, 480, w * 0.9, 0);
    rectM.set_rgb(r, g, b);
    rectM.anchor = Anchor.Left; // grow upward from middle
    bars_m.push(rectM);
}
