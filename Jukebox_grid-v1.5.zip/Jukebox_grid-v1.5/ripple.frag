#version 130

uniform sampler2D texture;   // the image to displace
uniform vec2 resolution;     // surface size
uniform float iAudio;        // smoothed FFT value
uniform float vScale;        // audio scale strength

void main() {
    vec2 uv = gl_TexCoord[0].st;

    // Center and distance from center
    vec2 center = vec2(0.5, 0.5);
    vec2 toUV = uv - center;
    float dist = length(toUV);

    // Phase depends only on audio
    float phase = dist * 60.0 - iAudio * 50.0;

    // Ripple wave
    float ripple = sin(phase);

    // Displacement magnitude depends entirely on audio
    float disp = ripple * (0.0 + iAudio * vScale * 3.0);

    // Apply displacement
    vec2 displacedUV = uv + normalize(toUV) * disp;

    // Sample displaced texture
    vec4 col = texture2D(texture, displacedUV);

    // Keep alpha
    //col.a = texture2D(texture, uv).a;

    gl_FragColor = col;
}
