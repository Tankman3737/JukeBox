/**
 * Jukebox_grid - Wurlitzer
 *
 * @summary It's a Jukebox.
 * @version 0.0.1 2026-1-4
 * @author Tankman3737
 * @url https://github.com/Tankman3737
 *
 * @requires
 * @module fade (Included with AM)
 * @module file (Included with AM)
 * @module inertia 3.00 https://github.com/oomek/attract-extra
 */

// class UserConfig {
//     </ label="Visualizers", help="Visualizers On/Off", options="Yes,No", order=5 />
//     Visualizers = "No";
// }

// cfg <- fe.get_config();

fe.layout.width = 1920;
fe.layout.height = 1080;
local my_config = fe.get_config();

local flx = fe.layout.width;
local fly = fe.layout.height;
local flw = fe.layout.width;
local flh = fe.layout.height;

fe.load_module("fade");
fe.load_module("inertia");
fe.load_module("file");

local bg = fe.add_image("artwork/wall.png");

//MARK:Ripple shader
local rippleSurf = fe.add_surface(575, 0, 825, 450);
local rect = rippleSurf.add_image("artwork/notes.png", 0, 0, 825, 450);
rect.zorder = 500;

// // // --- Shader ---
local rippleShader = fe.add_shader(Shader.Fragment, "ripple.frag");
rippleSurf.shader = rippleShader;

// --- Variables ---
local audioSmooth = 0.0;
local shaderTime = 0.0;
local vScale = 0.05;

// Force AUDIO mode
local useAudio = 10;

// --- Tick Callback ---

if (cfg["Visualizers"] == "Yes") {
    fe.add_ticks_callback("updateRippleShader");
    function updateRippleShader(tt) {
        shaderTime += tt * 0.001;

        local val = 0.0;
        if (fe.ambient_sound.fft.len() > 5) val = fe.ambient_sound.fft[5];
        audioSmooth = audioSmooth * 0.1 + val * 0.05;

        //rippleShader.set_param("ttime", shaderTime); // still updated
        rippleShader.set_param("iAudio", audioSmooth);
        rippleShader.set_param("vScale", vScale);
    }
}

//==============================================
//MARK: VOLUME CONTROL
//==============================================
local show_volume_display = false;
local volume_display_time = 0;
local volume_display_duration = 3000; // Show volume for 3 seconds

// Volume bars
local numBars = 10;
local barWidth = 46;
local barHeight = 18;
local spacing = 5;
local baseX = 740;
local baseY = 543;

local volumeBars = [];
for (local i = 0; i < numBars; i++) {
    local xPos = baseX + i * (barWidth + spacing);
    local rect = fe.add_rectangle(xPos, baseY, barWidth, barHeight);
    rect.alpha = 255; // ALWAYS VISIBLE

    local color;
    if (i < numBars * 0.6)
        color = 0x00FF00; // green
    else if (i < numBars * 0.8)
        color = 0xFFFF00; // yellow
    else color = 0xFF0000; // red

    rect.set_rgb((color >> 16) & 0xFF, (color >> 8) & 0xFF, color & 0xFF);
    rect.zorder = 1000;
    volumeBars.append(rect);
}

function load_initial_volume() {
    // Load from fe.nv instead of fe.ambient_sound.volume
    local vol = "ambient_volume" in fe.nv ? fe.nv.ambient_volume : 50;

    // Update bars to show current volume
    local activeBars = floor(vol / (100.0 / numBars));
    for (local i = 0; i < numBars; i++) {
        volumeBars[i].alpha = i < activeBars ? 255 : 80;
    }

    fe.log("Initial volume loaded from fe.nv: " + vol);
}

function show_volume(vol) {
    //volume_text.msg = "VOLUME: " + vol + "%";
    //volume_text.alpha = 0;
    show_volume_display = true;
    volume_display_time = fe.layout.time;

    // Update bars - ALWAYS VISIBLE, just change brightness
    local activeBars = floor(vol / (100.0 / numBars));
    for (local i = 0; i < numBars; i++) {
        volumeBars[i].alpha = i < activeBars ? 255 : 80;
    }
}

function hide_volume() {
    //volume_text.alpha = 0;
    // DON'T hide bars - keep them visible at current volume level
    show_volume_display = false;
}

function adjust_volume(amount) {
    local v = fe.ambient_sound.volume + amount;
    if (v < 0) v = 0;
    if (v > 100) v = 100;

    fe.ambient_sound.volume = v;
    fe.nv.ambient_volume = v; // Save to fe.nv instead of file

    show_volume(v);
}

// Continuous volume control variables
local volumeStep = 5;
local volumeChangeInterval = 200;
local lastVolumeChangeTime = 0;

fe.add_transition_callback("volume_transition");

//==============================================
//MARK: VISUALIZER
//==============================================

local vissurf = fe.add_surface(980, 680, 1080, 500);
local VW = 1080;
local VH = 1;
vissurf.anchor = Anchor.Centre;
vissurf.zorder = 1;

fe.ambient_sound.fft_bands = 68;

local w = VW.tofloat() / fe.ambient_sound.fft_bands;

local bars_m = [];

// Colour blocks (add/remove as you like)
local colors = [
    [ 255, 0, 0 ], // red
    [ 0, 0, 255 ], // blue
    [ 255, 255, 0 ], // yellow
    [ 255, 0, 255 ]  // magenta
];

for (local i = 0; i < fe.ambient_sound.fft_bands; i++) {
    // Pick colour based on block
    local chunk = fe.ambient_sound.fft_bands.tofloat() / colors.len().tofloat();
    local idx = (i / chunk).tointeger();
    if (idx >= colors.len()) idx = colors.len() - 1; // clamp to last colour
    local c = colors[idx];
    local r = c[0],
        g = c[1],
        b = c[2];

    // Mixed channel (middle)
    local rectM = vissurf.add_rectangle(i * w, 480, w * 0.9, 0);
    rectM.set_rgb(r, g, b);
    rectM.anchor = Anchor.Left; // grow upward from middle
    bars_m.push(rectM);
}

// Background

//==============================================
// ARROW LIGHT VISUALIZER (CREATE ONCE)
//==============================================

local arrowSurface = fe.add_surface(180, 440); // Width and height of arrow
arrowSurface.x = 1720; // Position on screen
arrowSurface.y = 780;
arrowSurface.zorder = 10;
arrowSurface.rotation = -40; // Uncomment to rotate
arrowSurface.anchor = Anchor.Centre; // Uncomment for centered rotation
arrowSurface.rotation_origin_x = 0.5;
arrowSurface.rotation_origin_y = 0.5;

// Add arrow base image to surface (now at 0,0 relative to surface)
local arrowBase = arrowSurface.add_image("artwork/arrow2.png", 0, 0, 180, 440);

local arrowLights = [];

// CONFIGURATION - Now relative to surface (0,0)
local arrowX = -18;
local arrowY = -180;
local arrowW = 220;
local arrowH = 600;

local lightSize = 12;
local centerX = arrowX + arrowW / 2;

local stemHeight = arrowH * 0.53;
local headHeight = arrowH * 0.4;

// --- CREATE STEM LIGHTS (on surface) ---
local stemLightSpacing = stemHeight / 14;

for (local i = 0; i < 16; i++) {
    local yPos = arrowY + arrowH - i * stemLightSpacing - stemLightSpacing;

    local light = arrowSurface.add_rectangle(centerX - lightSize / 2, yPos - lightSize / 2, lightSize, lightSize);
    light.set_rgb(255, 255, 0);
    light.alpha = 50;
    light.corner_ratio = 0.5;
    arrowLights.append(light);
}

// --- CREATE BOTH LEGS TOGETHER ---
local vSpacing = headHeight / 10;
local vWidth = arrowW / 3.8;

for (local i = 0; i < 4; i++) {
    local yPos = arrowY + stemHeight - i * vSpacing;
    local xOffset = (vWidth / 4) * (4 - i);

    // LEFT leg light
    local lightLeft = arrowSurface.add_rectangle(centerX - xOffset - lightSize / 2, yPos, lightSize, lightSize);
    lightLeft.set_rgb(255, 255, 0);
    lightLeft.alpha = 50;
    lightLeft.corner_ratio = 0.5;
    arrowLights.append(lightLeft);

    // RIGHT leg light
    local lightRight = arrowSurface.add_rectangle(centerX + xOffset - lightSize / 2, yPos, lightSize, lightSize);
    lightRight.set_rgb(255, 255, 0);
    lightRight.alpha = 50;
    lightRight.corner_ratio = 0.5;
    arrowLights.append(lightRight);
}

fe.log("Created " + arrowLights.len() + " arrow lights");

local arrow_clone = fe.add_clone(arrowSurface);
arrow_clone.x = 200;
arrow_clone.rotation = 40;

local guitar2 = fe.add_image("artwork/neon_on2.png", -190, 150, 600, 600);
guitar2.rotation = -20;
local guitar = fe.add_image("artwork/neon_off.png", -190, 150, 600, 600);
guitar.rotation = -20;

local AM_plusglow = fe.add_image("artwork/AM_glow.png", 1530, 100, 360, 150);
local AM_plus = fe.add_image("artwork/AM.png", 1530, 100, 360, 150);

//==============================================
// MODE CONTROL & PLUGIN - SAFE INITIALIZATION
//==============================================
local active_mode = 1; // Start with songs active

// SAFE PLUGIN CHECK
local audiomode = null;
local plugin_available = false;

try {
    if ("AudioMode_xtra" in fe.plugin) {
        audiomode = fe.plugin["AudioMode_xtra"];
        plugin_available = true;
        fe.log("INFO: AudioMode_xtra plugin loaded successfully");
    } else {
        fe.log("WARNING: AudioMode_xtra plugin not found, running in limited mode");
    }
} catch (e) {
    fe.log("ERROR: Failed to check for AudioMode_xtra plugin: " + e);
    plugin_available = false;
}

local top = fe.add_image("artwork/JB_topNEW2.png", 0, 0, 1920, 1080);

local glass = fe.add_image("artwork/glass2.png", 0, 0, 1920, 1080);
glass.zorder = 500;
glass.alpha = 128;
local frame = fe.add_image("artwork/frame.png", 0, 0, 1920, 1080);
frame.zorder = 50;

local vol_bar = fe.add_image("artwork/words2.png", 0, 0, 1920, 1080);
vol_bar.zorder = 510;

local words = fe.add_image("artwork/words.png", 0, 0, 1920, 1080);
words.zorder = 510;

//local switchto = fe.add_image("artwork/switch.png", 0, 0, 1920, 1080);
//==============================================
//MARK: MASTER SURFACE FOR TRANSFORMATION
//==============================================
// Create a surface that holds ALL albums, titles, and songs
// You can skew, pinch, rotate this entire surface to match your artwork
local master_surface = fe.add_surface(1920, 1080);
master_surface.x = -5;
master_surface.y = 0;
master_surface.width = 1920;
master_surface.height = 1080;

// TRANSFORMATION CONTROLS - Adjust these to fit your artwork
master_surface.skew_x = 10; // Horizontal skew (-100 to 100)
master_surface.skew_y = 0; // Vertical skew (-100 to 100)
master_surface.pinch_x = -50; // Horizontal pinch (-100 to 100)
master_surface.pinch_y = 0; // Vertical pinch (-100 to 100)
master_surface.rotation = 0; // Rotation in degrees
master_surface.alpha = 255; // Transparency (0-255)

//==============================================
// FOLDER STATE PERSISTENCE
//==============================================
if (!("jukebox_last_folder" in fe.nv)) {
    fe.nv.jukebox_last_folder <- 0;
}

if (!("jukebox_last_album" in fe.nv)) {
    fe.nv.jukebox_last_album <- 0;
}

if (!("jukebox_last_song" in fe.nv)) {
    fe.nv.jukebox_last_song <- 0;
}

local disc_surface = master_surface.add_surface(993, 582, 330, 800);
disc_surface.anchor = Anchor.Centre;
disc_surface.rotation_origin = Origin.Centre;
disc_surface.rotation = 0;

local centre_arm = disc_surface.add_image("artwork/centre_arm3.png", 0, 0, 330, 800);

local rect = master_surface.add_rectangle(450, 580, 1090, 400);
rect.set_rgb(0, 0, 0);

//==============================================
//MARK:ALBUM TO FOLDER MAPPING
//==============================================
//==============================================
// ALBUM TO FOLDER MAPPING - AUTO-DETECT FROM PLUGIN
//==============================================
// Auto-detect how many folders are configured
local total_albums = 0;
if (plugin_available && audiomode && audiomode.m_folders) {
    total_albums = audiomode.m_folders.len();
} else {
    fe.log("INFO: Running without AudioMode_xtra plugin, albums disabled");
}

// Build album to folder mapping dynamically
local album_to_folder_map = {};
for (local i = 0; i < total_albums; i++) {
    album_to_folder_map[i] <- i;
}
local visible_albums = 4;
local album_scroll_offset = 0; // Which album is leftmost (0-2, since we show 4 of 6)

// ALBUM POSITIONING & SIZE - ADJUST THESE TO MATCH YOUR BACKGROUND
local album_start_x = 475; // X position of first album
local album_start_y = 365; // Y position of albums
local album_width = 240; // Width of album artwork
local album_height = 220; // Height of album artwork
local album_spacing = 260; // Horizontal space between albums (includes room for song columns)

local current_album_selection = 0; // Which album is highlighted (0-5)

// Album button indicator - changes based on selected album
local album_buttons = fe.add_image("artwork/A_red.png", 1006, 994, 250, 44);
album_buttons.anchor = Anchor.Centre;
album_buttons.zorder = 500;

// Button image mapping for each album
local button_images = [ "A_red.png", "B_red.png", "C_red.png", "D_red.png", "E_red.png", "F_red.png" ];

function update_album_button() {
    if (current_album_selection >= 0 && current_album_selection < button_images.len()) {
        album_buttons.file_name = "artwork/" + button_images[current_album_selection];
        fe.log("Album button changed to: " + button_images[current_album_selection]);
    }
}

//==============================================
//MARK: ALBUM ART
//==============================================

// Create album cover images (loading cover.jpg from each folder)
local album_covers = [];
for (local i = 0; i < visible_albums; i++) {
    local x = album_start_x + i * album_spacing;
    local cover = master_surface.add_image("", x, 630, album_width, 275);
    cover.zorder = 1;
    cover.alpha = 70; // Hidden for now
    album_covers.push(cover);
}

// Album titles below artwork
local album_titles = [];
for (local i = 0; i < visible_albums; i++) {
    local x = album_start_x + i * album_spacing;
    // ALBUM TITLE POSITIONING - Adjust Y offset and height here
    local title = master_surface.add_text("", x, album_start_y + album_height + 10, album_width, 30);
    title.set_rgb(109, 0, 0);
    title.set_bg_rgb(255, 255, 255); // Default gray background
    title.bg_alpha = 0; // Start transparent
    title.align = Align.Centre;
    title.charsize = 18; // ALBUM TITLE FONT SIZE
    title.style = Style.Bold;
    album_titles.push(title);
}

//==============================================
//MARK: SPINNING CD
//==============================================
// SPINNING CD POSITIONING & SIZE - ADJUST THESE

local cd_x = 165; // X position (center of screen by default)
local cd_y = 150; // Y position above album list
local cd_size = 300; // Size of the spinning CD

// Create the spinning CD image (outside master_surface so it doesn't get skewed)
local spinning_cd = disc_surface.add_image("", cd_x, cd_y, cd_size, cd_size);
spinning_cd.rotation_origin = Origin.Centre;
spinning_cd.anchor = Anchor.Centre;
spinning_cd.zorder = 100;

local cd_x2 = 165; // X position (center of screen by default)
local cd_y2 = 650; // Y position above album list
local cd_size2 = 300; // Size of the spinning CD

// Create the second spinning CD image
local spinning_cd2 = disc_surface.add_image("", cd_x2, cd_y2, cd_size2, cd_size2);
spinning_cd2.rotation_origin = Origin.Centre;
spinning_cd2.anchor = Anchor.Centre;
spinning_cd2.zorder = 100;

// Rotation animation
fe.add_ticks_callback("spin_cd");
function spin_cd(ttime) {
    spinning_cd.rotation += 2; // Adjust speed (higher = faster)
    if (spinning_cd.rotation >= 360) spinning_cd.rotation = 0;
}

fe.add_ticks_callback("spin_cd2");
function spin_cd2(ttime) {
    spinning_cd2.rotation += 2; // Adjust speed (higher = faster)
    if (spinning_cd2.rotation >= 360) spinning_cd2.rotation = 0;
}

// Function to update the spinning CD with current album's cover
local pending_cd_update = false; // Flag to track if we need to update CD
local target_album_for_cd = 0; // Which album to show when disc returns
local cd_update_time = 0; // When to update the CD

function update_spinning_cd() {
    if (plugin_available && audiomode && current_album_selection < audiomode.m_folders.len()) {
        local cover_path = audiomode.m_folders[current_album_selection] + "/cd.png";
        spinning_cd.file_name = cover_path;
        fe.log("Spinning CD: " + cover_path);
    } else {
        spinning_cd.file_name = "";
    }
}

function update_spinning_cd2() {
    if (plugin_available && audiomode && current_album_selection < audiomode.m_folders.len()) {
        local cover_path = audiomode.m_folders[current_album_selection] + "/cd.png";
        spinning_cd2.file_name = cover_path;
        fe.log("Spinning CD2: " + cover_path);
    } else {
        spinning_cd2.file_name = "";
    }
}

function update_spinning_cd2_immediate() {
    // Update CD2 with the TARGET album (new selection) immediately
    if (plugin_available && audiomode && target_album_for_cd < audiomode.m_folders.len()) {
        local cover_path = audiomode.m_folders[target_album_for_cd] + "/cd.png";
        spinning_cd2.file_name = cover_path;
        fe.log("Spinning CD2 updated immediately to new album");
    } else {
        spinning_cd2.file_name = "";
    }
}

function schedule_cd_update(delay_ms) {
    // Schedule a CD update after a delay (in milliseconds)
    pending_cd_update = true;
    target_album_for_cd = current_album_selection;
    cd_update_time = fe.layout.time + delay_ms;

    // Update CD2 immediately with the NEW album
    update_spinning_cd2_immediate();

    fe.log("CD1 update scheduled for " + delay_ms + "ms, CD2 updated immediately");
}

function update_album_display() {
    // Calculate which albums to show based on scroll offset
    for (local i = 0; i < visible_albums; i++) {
        local album_index = album_scroll_offset + i;

        if (album_index < total_albums) {
            // Load cover.jpg from the album's folder
            local cover_path = "";
            if (plugin_available && audiomode && audiomode.m_folders && album_index < audiomode.m_folders.len()) {
                cover_path = audiomode.m_folders[album_index] + "/cover.jpg";
            }
            album_covers[i].file_name = cover_path;

            // Get actual folder name from AudioMode_xtra
            if (plugin_available && audiomode) {
                local folder_name = audiomode.get_folder_name(album_index);
                album_titles[i].msg = folder_name.len() > 0 ? folder_name : "Album " + (album_index + 1);
            } else {
                album_titles[i].msg = "Please enable ";
            }

            album_covers[i].visible = true;
            album_titles[i].visible = true;

            // Highlight the selected album's title
            if (album_index == current_album_selection) {
                if (active_mode == 0) {
                    album_titles[i].set_bg_rgb(255, 255, 0); // Yellow in album mode
                    album_titles[i].bg_alpha = 200;
                } else {
                    album_titles[i].set_bg_rgb(255, 255, 0); // Gray in song mode
                    album_titles[i].bg_alpha = 255;
                }
            } else {
                album_titles[i].bg_alpha = 0; // No highlight
            }
        } else {
            album_covers[i].visible = false;
            album_titles[i].visible = false;
        }
    }
}

//==============================================
//MARK: SONG LISTS
//==============================================

// Store song lists for each album/folder
local album_song_lists = []; // Array of arrays - one per album
local album_display_names = []; // Array of arrays - display names per album

// Load all song lists for all albums
function load_all_song_lists() {
    album_song_lists = [];
    album_display_names = [];

    if (!plugin_available || !audiomode) {
        fe.log("INFO: AudioMode_xtra not available, no songs loaded");
        // Add dummy data to prevent crashes
        album_song_lists.push([]);
        album_display_names.push(["Audiomode_xtra plugin"]);
        total_albums = 1;
        return;
    }

    // Load songs for each of the albums
    for (local album_idx = 0; album_idx < total_albums; album_idx++) {
        local folder_idx = album_to_folder_map[album_idx];

        // Get the folder path
        if (folder_idx < audiomode.m_folders.len()) {
            local folder_path = audiomode.m_folders[folder_idx];
            local dir = DirectoryListing(folder_path);

            local song_files = [];
            local display_names = [];

            foreach (filename in dir.results) {
                // Skip image files (cover.jpg, artwork, etc.)
                local lower_filename = filename.tolower();
                if (lower_filename.find(".jpg") != null || lower_filename.find(".jpeg") != null || lower_filename.find(".png") != null || lower_filename.find(".gif") != null || lower_filename.find(".bmp") != null) {
                    continue; // Skip this file
                }

                song_files.push(filename);

                // Extract display name
                local display_name = filename;
                local parts = split(filename, "/\\");
                if (parts.len() > 0) {
                    display_name = parts[parts.len() - 1];

                    // Remove extension
                    local dot_pos = display_name.find(".", display_name.len() - 5);
                    if (dot_pos != null) {
                        display_name = display_name.slice(0, dot_pos);
                    }
                }

                display_names.push(display_name);
            }

            album_song_lists.push(song_files);
            album_display_names.push(display_names);

            fe.log("Album " + album_idx + ": Loaded " + song_files.len() + " songs");
        } else {
            album_song_lists.push([]);
            album_display_names.push([]);
        }
    }
}

// SONG COLUMN POSITIONING & SIZE - ADJUST THESE TO MATCH YOUR BACKGROUND
local song_column_y = 630; // Y position where song lists start (below album titles)
local visible_songs_per_album = 7; // Number of visible songs per album column
local song_line_height = 40; // Height of each song row
local song_column_width = 240; // Width of each song column

// Current selections
local current_song_selection = 0; // Which song in the active album

// Create song text objects for each album column (4 visible albums × 7 songs)
local song_columns = []; // Array of arrays

for (local album_col = 0; album_col < visible_albums; album_col++) {
    local column = [];
    local x = album_start_x + album_col * album_spacing;

    for (local row = 0; row < visible_songs_per_album; row++) {
        local y = song_column_y + row * song_line_height;

        local txt = master_surface.add_text("", x, y, song_column_width, song_line_height - 2);
        txt.set_rgb(0, 0, 0); // SONG TEXT COLOR - Black
        txt.set_bg_rgb(255, 255, 255); // SONG BACKGROUND COLOR - White
        txt.bg_alpha = 255;
        txt.charsize = 14; // SONG FONT SIZE
        txt.word_wrap = true;
        txt.style = Style.Bold;
        column.push(txt);
    }

    song_columns.push(column);
}

//==============================================
// SONG SELECTION BUTTONS (1-26)
//==============================================
local song_button_start_x = 582; // X position of first button
local song_button_y = 952; // Y position of button row
local song_button_width = 19; // Width of each button
local song_button_height = 34; // Height of each button
local song_button_spacing = 22.8; // Space between buttons
local song_button_gap = 258; // Gap between button 13 and 14

local song_buttons = []; // Array to hold all 26 button rectangles

// Create 26 song buttons (1-13, then gap, then 14-26)
for (local i = 0; i < 26; i++) {
    local x_pos;
    if (i < 13) {
        // Buttons 1-13
        x_pos = song_button_start_x + i * song_button_spacing;
    } else {
        // Buttons 14-26 (after gap)
        x_pos = song_button_start_x + i * song_button_spacing + song_button_gap;
    }

    local btn = fe.add_rectangle(x_pos, song_button_y, song_button_width, song_button_height);
    btn.set_rgb(100, 0, 0); // Dark red (unlit)
    btn.zorder = 450;
    btn.corner_ratio = 0.2;

    song_buttons.push(btn);
}

local song_button_start_x2 = 582; // X position of first button
local song_button_y2 = 912; // Y position of button row
local song_button_width2 = 22; // Width of each button
local song_button_height2 = 34; // Height of each button
local song_button_spacing2 = 22.8; // Space between buttons
local song_button_gap2 = 258; // Gap between button 13 and 14

local song_buttons2 = []; // Array to hold all 26 button rectangles

// Create 26 song buttons (1-13, then gap, then 14-26)
for (local i = 0; i < 26; i++) {
    local x_pos2;
    if (i < 13) {
        // Buttons 1-13
        x_pos2 = song_button_start_x2 + i * song_button_spacing2;
    } else {
        // Buttons 14-26 (after gap)
        x_pos2 = song_button_start_x2 + i * song_button_spacing2 + song_button_gap2;
    }

    local btn2 = fe.add_rectangle(x_pos2, song_button_y2, song_button_width2, song_button_height2);
    btn2.set_rgb(0, 0, 0); // Dark red (unlit)
    btn2.zorder = 450;
    btn2.corner_ratio = 0.2;

    song_buttons2.push(btn2);
}

function update_song_buttons() {
    // Update buttons based on current song selection
    for (local i = 0; i < song_buttons2.len(); i++) {
        if (i == current_song_selection && active_mode == 1) {
            song_buttons2[i].set_rgb(218, 204, 204); // Bright red (lit)
            song_buttons[i].set_rgb(255, 0, 0); // Bright red (lit)
        } else {
            song_buttons2[i].set_rgb(0, 0, 0); // Dark red (unlit)
            song_buttons[i].set_rgb(100, 0, 0); // Dark red (unlit)
        }
    }
}

local bg_bottom = fe.add_image("artwork/JB_bottomNEW5.png", 0, -1, 1920, 1080);
bg_bottom.zorder = 490;

local vol_back = fe.add_image("artwork/vol_back.png", 0, 0, 1920, 1080);
vol_back.zorder = 500;

function update_all_song_columns() {
    // Update all 4 visible album columns
    for (local col = 0; col < visible_albums; col++) {
        local album_index = album_scroll_offset + col;

        if (album_index < total_albums && album_index < album_song_lists.len()) {
            local songs = album_display_names[album_index];

            // Calculate scroll offset for the active album's song list
            local song_scroll_offset = 0;
            if (album_index == current_album_selection) {
                // This is the active album - apply scrolling
                if (current_song_selection >= visible_songs_per_album / 2) {
                    song_scroll_offset = current_song_selection - visible_songs_per_album / 2;
                    if (song_scroll_offset + visible_songs_per_album > songs.len()) {
                        song_scroll_offset = songs.len() - visible_songs_per_album;
                        if (song_scroll_offset < 0) song_scroll_offset = 0;
                    }
                }
            }

            // Display up to 7 songs for this album
            for (local row = 0; row < visible_songs_per_album; row++) {
                local song_index = row + song_scroll_offset;

                if (song_index < songs.len()) {
                    song_columns[col][row].msg = songs[song_index];
                    song_columns[col][row].visible = true;

                    // Highlight selected song in active album
                    if (album_index == current_album_selection && song_index == current_song_selection && active_mode == 1) {
                        song_columns[col][row].set_bg_rgb(255, 0, 0); // Red when selected
                    } else {
                        song_columns[col][row].set_bg_rgb(255, 255, 255); // White otherwise
                    }
                } else {
                    song_columns[col][row].msg = "";
                    song_columns[col][row].visible = false;
                }
            }
        } else {
            // No album in this position - hide all songs
            for (local row = 0; row < visible_songs_per_album; row++) {
                song_columns[col][row].visible = false;
            }
        }
    }
}

// Initial display - load all songs for all albums
load_all_song_lists();

current_album_selection = fe.nv.jukebox_last_album;
if (current_album_selection >= total_albums && total_albums > 0) {
    current_album_selection = 0;
} else if (total_albums == 0) {
    current_album_selection = 0;
}

current_song_selection = fe.nv.jukebox_last_song;
if (current_song_selection >= 7) current_song_selection = 0;

// Calculate scroll offset so the selected album is visible
if (current_album_selection < album_scroll_offset) {
    album_scroll_offset = current_album_selection;
} else if (current_album_selection >= album_scroll_offset + visible_albums) {
    album_scroll_offset = current_album_selection - visible_albums + 1;
}

// Sync AudioMode_xtra to the remembered album on startup
if (plugin_available && audiomode && current_album_selection in album_to_folder_map) {
    local folder_index = album_to_folder_map[current_album_selection];
    if (folder_index >= 0 && folder_index != audiomode.get_current_folder()) {
        fe.log("Startup: Restoring last album - switching to folder " + folder_index);
        audiomode.switch_to_folder(folder_index);
        fe.nv.jukebox_last_folder = folder_index;
    }
}

update_album_display();
update_all_song_columns();
if (plugin_available) {
    update_spinning_cd();
    update_spinning_cd2();
}
update_album_button();
update_song_buttons();

load_initial_volume(); // Add this line

fe.log("Jukebox layout loaded successfully - Plugin available: " + plugin_available);

//==============================================
// SIGNAL HANDLER
//==============================================
disc_surface = Inertia(disc_surface, 2500, "rotation");
//disc_surface.tween_all = Tween.Linear
fe.add_signal_handler("jukebox_signal");

function jukebox_signal(signal) {
    // CRITICAL: Never block exit or layout change signals
    if (signal == "exit_to_menu" || signal == "exit_game" || 
        signal == "prev_layout" || signal == "next_layout") {
        return false;
    }

    if (!plugin_available) {
        // When plugin not available, handle basic signals
        if (signal == "custom4") {
            active_mode = (active_mode == 1) ? 0 : 1;
            return true;
        }
        // Block navigation but NOT exit signals
        if (signal == "left" || signal == "right" || signal == "up" || signal == "down" || signal == "select") {
            return true;
        }
        return false;
    }

    // VOLUME CONTROL - Works in both modes

    // CUSTOM4 only works in SONG MODE to return to album mode
    if (signal == "custom4" && active_mode == 1) {
        // Switch from song mode to album mode
        active_mode = 0;

        update_album_display();
        update_all_song_columns();
        return true;
    }

    // Handle navigation based on active mode
    if (active_mode == 0) {
        // ALBUM MODE - navigate albums
        if (signal == "select") {
            // SELECT (A button) activates the album and switches to song mode
            local folder_index = -1;
            if (current_album_selection in album_to_folder_map) {
                folder_index = album_to_folder_map[current_album_selection];

                disc_surface.rotation = 0;
                disc_surface.to_rotation = -180;

                schedule_cd_update(2500);
                update_album_button();
            }

            if (folder_index >= 0) {
                // Switch to this album's folder
                if (folder_index != audiomode.get_current_folder()) {
                    audiomode.switch_to_folder(folder_index);
                    fe.nv.jukebox_last_folder = folder_index;
                }

                // Play first song
                current_song_selection = 0;
                if (album_song_lists[current_album_selection].len() > 0) {
                    audiomode.m_index = 0;
                    audiomode.change_track(0);
                }

                // Switch to song mode
                active_mode = 1;
                fe.nv.jukebox_last_song = 0;

                update_album_display();
                update_all_song_columns();
                update_song_buttons();
            }
            return true;
        } else if (signal == "left") {
            if (total_albums == 0) return true;

            current_album_selection--;
            if (current_album_selection < 0) {
                current_album_selection = total_albums - 1;
            }

            // Adjust scroll offset if needed
            if (current_album_selection < album_scroll_offset) {
                album_scroll_offset = current_album_selection;
            } else if (current_album_selection >= album_scroll_offset + visible_albums) {
                album_scroll_offset = current_album_selection - visible_albums + 1;
            }

            fe.nv.jukebox_last_album = current_album_selection;
            update_album_display();
            update_all_song_columns();
            return true;
        } else if (signal == "right") {
            if (total_albums == 0) return true;

            current_album_selection++;
            if (current_album_selection >= total_albums) {
                current_album_selection = 0;
            }

            // Adjust scroll offset if needed
            if (current_album_selection < album_scroll_offset) {
                album_scroll_offset = current_album_selection;
            } else if (current_album_selection >= album_scroll_offset + visible_albums) {
                album_scroll_offset = current_album_selection - visible_albums + 1;
            }

            fe.nv.jukebox_last_album = current_album_selection;
            update_album_display();
            update_all_song_columns();
            return true;
        }
    } else {
        // SONG MODE - navigate songs in active album
        if (!plugin_available || !audiomode) {
            return true;
        }

        local current_album_songs = album_song_lists[current_album_selection];
        if (current_album_songs.len() == 0) return false;

        if (signal == "up") {
            current_song_selection--;
            if (current_song_selection < 0) {
                current_song_selection = current_album_songs.len() - 1;
            }
            fe.nv.jukebox_last_song = current_song_selection;

            // Auto-play on navigation
            if (audiomode.m_index != null) {
                audiomode.m_index = current_song_selection;
                audiomode.change_track(0);
            }

            update_all_song_columns();
            update_song_buttons();
            return true;
        } else if (signal == "down") {
            current_song_selection++;
            if (current_song_selection >= current_album_songs.len()) {
                current_song_selection = 0;
            }
            fe.nv.jukebox_last_song = current_song_selection;

            // Auto-play on navigation
            if (audiomode.m_index != null) {
                audiomode.m_index = current_song_selection;
                audiomode.change_track(0);
            }

            update_all_song_columns();
            update_song_buttons();
            return true;
        }
    }

    // Block all navigation signals from reaching the romlist
    if (signal == "up" || signal == "down" || signal == "left" || signal == "right" || signal == "select") {
        return false;
    }

    return false;
}

//==============================================
// TICK CALLBACK FOR AUTO-ADVANCE AND CD UPDATE
//==============================================
//MARK:Ticks
local last_check = 0;

fe.add_ticks_callback("jukebox_tick");
function jukebox_tick(ttime) {
    // CALCULATE FFT SUM FIRST (needed by multiple visualizers)
    local fftSum = 0.0;
    for (local i = 0; i < fe.ambient_sound.fft_bands; i++) {
        fftSum += fe.ambient_sound.fft[i];
    }

    if (cfg["Visualizers"] == "Yes") {
        // ARROW LIGHT VISUALIZER - Light up from bottom to top
        local totalLights = arrowLights.len(); // Should be 32 (20 + 6 + 6)
        local fftAvg = fftSum / fe.ambient_sound.fft_bands.tofloat();

        // Calculate how many lights should be on (0 to totalLights)
        local lightsOn = floor(fftAvg * totalLights * 2.5).tointeger(); // Multiply by 3.0 for sensitivity
        if (lightsOn > totalLights) lightsOn = totalLights;

        // Update each light
        for (local i = 0; i < totalLights; i++) {
            if (i < lightsOn) {
                arrowLights[i].alpha = 255; // Bright orange
            } else {
                arrowLights[i].alpha = 50; // Dim
            }
        }

        // ARROW ROTATION - Rotate based on audio intensity
        local rotationAmount = fftAvg * 40.0; // Max 30 degrees rotation
        local targetRotation = -15 + rotationAmount; // Swing from -15 to +15 degrees
        local targetRotation2 = -15 + rotationAmount; // Swing from -15 to +15 degrees
        // Smooth rotation (optional - removes jitter)
        arrowSurface.rotation = arrowSurface.rotation * 0.8 + targetRotation * 0.5;

        arrow_clone.rotation = arrow_clone.rotation * 0.8 - targetRotation2 * 0.5;

        // MUSIC VISUALIZER UPDATE
        local gain = 1.0; // scale factor for bigger movement
        local fftSum = 0.0;
        for (local i = 0; i < fe.ambient_sound.fft_bands; i++) {
            bars_m[i].height = (fe.ambient_sound.fft[i] * flh) / 5;
            fftSum += fe.ambient_sound.fft[i]; // Sum up all FFT values
        }

        // NEON SIGN PULSE - Drive alpha with average FFT
        local avgFFT = fftSum / fe.ambient_sound.fft_bands.tofloat();
        local neonAlpha = 55 + (avgFFT * 400).tointeger(); // Base alpha 155, pulse up to 255
        if (neonAlpha > 255) neonAlpha = 255;
        if (neonAlpha < 155) neonAlpha = 100;
        guitar2.alpha = neonAlpha;

        //AttractMode Logo
        local avgFFT = fftSum / fe.ambient_sound.fft_bands.tofloat();
        local Logo = 45 + (avgFFT * 350).tointeger(); // Base alpha 155, pulse up to 255
        if (Logo > 255) Logo = 255;
        if (Logo < 155) Logo = 55;
        AM_plusglow.alpha = Logo;
    }

    // CONTINUOUS VOLUME CONTROL
    local downState = fe.get_input_state("custom2");
    local upState = fe.get_input_state("custom1");

    if (ttime - lastVolumeChangeTime >= volumeChangeInterval) {
        if (downState && fe.ambient_sound.volume > 0) {
            adjust_volume(-volumeStep);
            lastVolumeChangeTime = ttime;
        } else if (upState && fe.ambient_sound.volume < 100) {
            adjust_volume(volumeStep);
            lastVolumeChangeTime = ttime;
        }
    }

    // Auto-hide volume display after 3 seconds
    if (show_volume_display && ttime - volume_display_time > volume_display_duration) {
        hide_volume();
    }

    // Check if it's time to update the CD
    if (pending_cd_update && ttime >= cd_update_time) {
        update_spinning_cd();
        pending_cd_update = false;
        fe.log("CD updated after scheduled delay");
    }

    // Auto-sync with audiomode (only if plugin available)
    if (plugin_available && ttime - last_check > 1000) {
        if (audiomode && audiomode.m_index != null) {
            local audiomode_index = audiomode.m_index;

            // Sync selection to what's playing (in case song auto-advanced)
            if (audiomode_index != current_song_selection && audiomode_index >= 0) {
                local current_album_songs = album_song_lists[current_album_selection];
                if (audiomode_index < current_album_songs.len()) {
                    current_song_selection = audiomode_index;
                    update_all_song_columns();
                    update_song_buttons();
                    fe.nv.jukebox_last_song = current_song_selection;
                }
            }
        }
        last_check = ttime;
    }
}

fe.log("Jukebox layout loaded successfully");